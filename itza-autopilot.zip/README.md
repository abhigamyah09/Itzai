# ITZA AutoPilot

AI agent dashboard for automating [itza.io](https://www.itza.io) — play quizzes, watch courses, browse content, with a shared interactive browser session.

## Features

- **Interactive ITZA Browser** — a live view of a real Playwright-controlled Chromium browser showing itza.io. You can click, type, and navigate manually.
- **AI Agent** — give natural-language tasks ("Play the cricket quiz", "Watch Ocean Odyssey videos") and the LLM-powered agent drives the same browser session.
- **Shared Session** — your manual login persists when the agent takes over. Sign in once, the agent inherits your login.
- **Take-Turns Mode** — only one driver at a time (you OR the agent), preventing conflicts.
- **Live Screenshots** — the browser panel auto-refreshes every 1-2 seconds showing the current page state.
- **6 Task Templates** — Play a Quiz, Watch a Course, Browse Trending, Explore Everything, Sign In Only, Custom Task.

## Tech Stack

- **Framework**: Next.js 16 with App Router + TypeScript
- **Styling**: Tailwind CSS 4 + shadcn/ui components
- **Browser Automation**: Playwright (headless Chromium)
- **LLM**: z-ai-web-dev-sdk (for task planning + quiz answering)
- **Toasts**: Sonner

## Setup

```bash
# Install dependencies
bun install

# Install Playwright browser
bunx playwright install chromium

# Start dev server
bun run dev
```

The app runs on `http://localhost:3000`.

## How to Use

1. **Wait for itza.io to load** — on first load, the browser panel takes ~15-20 seconds to load itza.io (it's a heavy Next.js site). You'll see a loading spinner.

2. **Sign in manually** — once itza.io is visible, click the "Sign In" button on the itza.io page (top-right). Use ITZA's official Google/email login. Type your email/password using the input box below the browser panel.

3. **Run the agent** — once signed in, write a task in the prompt box (e.g. "Play the cricket quiz") and click "Run agent". The agent takes over the same browser (already logged in as you).

4. **Watch the agent work** — the browser panel shows the agent clicking through pages in real-time. The "AGENT DRIVING" badge appears. When it finishes, control returns to you ("MANUAL" badge).

## Mobile Usage

- The dashboard is fully responsive. On mobile, the browser panel and task panel stack vertically.
- Screenshots are JPEG (quality 70, ~150KB) instead of PNG (~1.4MB) for faster loading on mobile networks.
- Refresh interval is longer on mobile (1.5-2s vs 0.8-1.2s on desktop) to reduce data usage.
- If you see "Browser is still loading..." — just wait a few seconds. The Playwright browser takes 3-5 seconds to launch + 15-20 seconds to load itza.io.

## API Routes

### Agent Control
- `POST /api/agent/start` — start an agent run with a task prompt
- `POST /api/agent/stop` — stop a running agent
- `GET /api/agent/status?sessionId=X` — get live session state (plan, log, screenshots)
- `GET /api/agent/sessions` — list recent sessions
- `POST /api/agent/delete` — delete a session

### Browser Control (manual mode)
- `GET /api/browser/screenshot` — get current page as JPEG
- `GET /api/browser/state` — get mode (manual/agent) + current URL/title
- `POST /api/browser/init` — trigger browser initialization (fire-and-forget)
- `POST /api/browser/click` — click at {x, y} coordinates
- `POST /api/browser/type` — type text into focused element
- `POST /api/browser/key` — press a key (Enter, Tab, Backspace, etc.)
- `POST /api/browser/navigate` — navigate to a URL (itza.io only)
- `POST /api/browser/scroll` — scroll up/down
- `POST /api/browser/back` | `/forward` | `/reload` — browser history

## Architecture

```
src/
├── app/
│   ├── api/
│   │   ├── agent/          # Agent control routes
│   │   └── browser/        # Manual browser control routes
│   ├── layout.tsx          # Root layout (mounts Sonner toaster)
│   └── page.tsx            # Main dashboard (side-by-side layout)
├── lib/
│   └── agent/
│       ├── sessions.ts     # In-memory session store
│       ├── llm-planner.ts  # z-ai LLM calls (plan, answer quiz, decide)
│       ├── itza-engine.ts  # Playwright browser engine + manual control
│       └── orchestrator.ts # Agent run coordinator (mode switching)
└── components/ui/          # shadcn/ui components
```

## Notes

- Credentials are kept in-memory only — never written to disk.
- Only itza.io URLs are allowed (security gate in `sanitizeItzaUrl`).
- One agent run at a time (single shared Playwright browser).
- Screenshots are NOT saved to disk for the live browser view (only for agent runs).

## Troubleshooting

- **"Browser is still loading..."** — wait 15-20 seconds for itza.io to load.
- **"500 Internal Server Error"** — this should not happen anymore. If it does, check that the dev server is running and Playwright Chromium is installed.
- **Blank browser panel** — the screenshot is loading. Wait for the next refresh cycle (1-2 seconds).
- **Clicks not working** — make sure the "MANUAL" badge is showing (not "AGENT DRIVING"). The agent might still be running.
