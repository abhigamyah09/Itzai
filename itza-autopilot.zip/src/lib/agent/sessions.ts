/**
 * In-memory session store for agent runs.
 *
 * Each session represents one agent execution: a user-provided task prompt,
 * the plan the LLM produced, the actions executed so far, screenshots, and
 * a rolling log. The store is intentionally in-memory and per-process —
 * we do not persist user credentials or browsing data anywhere.
 */

import path from "path";
import fs from "fs";

export type SessionStatus =
  | "queued"
  | "planning"
  | "running"
  | "completed"
  | "failed"
  | "stopped";

export type ActionStatus = "pending" | "running" | "done" | "skipped" | "error";

export interface AgentAction {
  id: string;
  index: number;
  type:
    | "navigate"
    | "login"
    | "explore"
    | "play_quiz"
    | "watch_video"
    | "browse"
    | "snapshot"
    | "click"
    | "fill"
    | "wait"
    | "answer_quiz"
    | "custom";
  description: string;
  status: ActionStatus;
  startedAt?: number;
  finishedAt?: number;
  detail?: string;
  screenshotPath?: string;
}

export interface LogEntry {
  id: string;
  ts: number;
  level: "info" | "success" | "warn" | "error" | "debug";
  message: string;
}

export interface ScreenshotRecord {
  id: string;
  ts: number;
  path: string;
  caption: string;
  actionIndex?: number;
}

export interface AgentSession {
  id: string;
  taskKind: string; // "quiz" | "video" | "browse" | "custom" | "login" | "explore"
  prompt: string;
  status: SessionStatus;
  createdAt: number;
  updatedAt: number;
  startedAt?: number;
  finishedAt?: number;
  plan: AgentAction[];
  log: LogEntry[];
  screenshots: ScreenshotRecord[];
  currentPageUrl?: string;
  currentPageTitle?: string;
  errorMessage?: string;
  stats: {
    actionsCompleted: number;
    quizzesAnswered: number;
    videosWatched: number;
    pagesVisited: number;
  };
  stopRequested: boolean;
}

const MAX_SESSIONS = 50;
const MAX_LOG_ENTRIES = 500;
const MAX_SCREENSHOTS = 80;
const MAX_LOG_MESSAGE_LEN = 500;
const SCREENSHOTS_DIR = path.join(process.cwd(), "public", "screenshots");

class SessionStore {
  private sessions = new Map<string, AgentSession>();
  private order: string[] = [];

  create(input: {
    taskKind: string;
    prompt: string;
  }): AgentSession {
    const id =
      "s_" +
      Date.now().toString(36) +
      "_" +
      Math.random().toString(36).slice(2, 8);
    const now = Date.now();
    const session: AgentSession = {
      id,
      taskKind: input.taskKind,
      prompt: input.prompt,
      status: "queued",
      createdAt: now,
      updatedAt: now,
      plan: [],
      log: [],
      screenshots: [],
      stats: {
        actionsCompleted: 0,
        quizzesAnswered: 0,
        videosWatched: 0,
        pagesVisited: 0,
      },
      stopRequested: false,
    };
    this.sessions.set(id, session);
    this.order.unshift(id);
    // Cap history at MAX_SESSIONS — clean up screenshots for evicted sessions
    while (this.order.length > MAX_SESSIONS) {
      const old = this.order.pop();
      if (old) this.evict(old);
    }
    return session;
  }

  get(id: string): AgentSession | undefined {
    return this.sessions.get(id);
  }

  list(): AgentSession[] {
    return this.order
      .map((id) => this.sessions.get(id))
      .filter((s): s is AgentSession => !!s);
  }

  update(id: string, patch: Partial<AgentSession>): AgentSession | undefined {
    const s = this.sessions.get(id);
    if (!s) return undefined;
    Object.assign(s, patch, { updatedAt: Date.now() });
    return s;
  }

  log(
    id: string,
    level: LogEntry["level"],
    message: string,
  ): void {
    const s = this.sessions.get(id);
    if (!s) return;
    const safeMessage =
      typeof message === "string"
        ? message.length > MAX_LOG_MESSAGE_LEN
          ? message.slice(0, MAX_LOG_MESSAGE_LEN) + "…"
          : message
        : String(message);
    s.log.push({
      id: "l_" + Math.random().toString(36).slice(2, 9),
      ts: Date.now(),
      level,
      message: safeMessage,
    });
    if (s.log.length > MAX_LOG_ENTRIES) s.log = s.log.slice(-MAX_LOG_ENTRIES);
    s.updatedAt = Date.now();
  }

  addScreenshot(
    id: string,
    screenshotPath: string,
    caption: string,
    actionIndex?: number,
  ): void {
    const s = this.sessions.get(id);
    if (!s) return;
    const rec: ScreenshotRecord = {
      id: "sc_" + Math.random().toString(36).slice(2, 9),
      ts: Date.now(),
      path: screenshotPath,
      caption:
        typeof caption === "string"
          ? caption.slice(0, 200)
          : "Screenshot",
      actionIndex,
    };
    s.screenshots.push(rec);
    if (s.screenshots.length > MAX_SCREENSHOTS) {
      // Drop oldest screenshot record AND delete the file from disk
      const dropped = s.screenshots.shift();
      if (dropped) this.deleteScreenshotFile(dropped.path);
    }
    s.updatedAt = Date.now();
  }

  /**
   * Remove a session from the store and delete its screenshot files from disk.
   */
  remove(id: string): boolean {
    const s = this.sessions.get(id);
    if (!s) return false;
    for (const sc of s.screenshots) {
      this.deleteScreenshotFile(sc.path);
    }
    this.sessions.delete(id);
    this.order = this.order.filter((x) => x !== id);
    return true;
  }

  /** Internal: evict a session (called when history rolls over). */
  private evict(id: string): void {
    const s = this.sessions.get(id);
    if (s) {
      for (const sc of s.screenshots) {
        this.deleteScreenshotFile(sc.path);
      }
    }
    this.sessions.delete(id);
  }

  private deleteScreenshotFile(publicPath: string): void {
    try {
      // publicPath looks like "/screenshots/<file>.png"
      if (!publicPath || !publicPath.startsWith("/screenshots/")) return;
      const filename = path.basename(publicPath);
      // Guard against path traversal: filename must be a simple basename
      if (filename.includes("/") || filename.includes("..")) return;
      const abs = path.join(SCREENSHOTS_DIR, filename);
      fs.promises.unlink(abs).catch(() => {
        /* best effort */
      });
    } catch {
      /* ignore */
    }
  }
}

// Singleton — survives across hot reloads in dev when we stash on globalThis.
// We version the cache key so that when this file's API changes, a stale
// instance from a previous compile is not reused (which would cause methods
// added/changed in the new code to be missing on the old instance).
const STORE_VERSION = "v2-2026-06-28";
const g = globalThis as unknown as {
  __agentSessionStore?: SessionStore;
  __agentSessionStoreVersion?: string;
};
function getStore(): SessionStore {
  if (g.__agentSessionStore && g.__agentSessionStoreVersion === STORE_VERSION) {
    return g.__agentSessionStore;
  }
  const fresh = new SessionStore();
  g.__agentSessionStore = fresh;
  g.__agentSessionStoreVersion = STORE_VERSION;
  return fresh;
}
export const sessionStore: SessionStore = getStore();

/**
 * Returns a deep-cloned, length-bounded view of the session safe to send to
 * the client. The client must not be able to mutate server-side state via
 * the returned object (which is why we clone the arrays).
 */
export function sanitizeSessionForClient(s: AgentSession) {
  return {
    id: s.id,
    taskKind: s.taskKind,
    prompt: s.prompt,
    status: s.status,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
    startedAt: s.startedAt,
    finishedAt: s.finishedAt,
    // Clone actions so client React state mutations can't leak into server
    plan: s.plan.map((a) => ({ ...a })),
    // Send last 200 log entries, cloned
    log: s.log.slice(-200).map((l) => ({ ...l })),
    // Clone screenshot records (path included so client can render <img>)
    screenshots: s.screenshots.map((sc) => ({
      id: sc.id,
      ts: sc.ts,
      caption: sc.caption,
      actionIndex: sc.actionIndex,
      path: sc.path,
    })),
    currentPageUrl: s.currentPageUrl,
    currentPageTitle: s.currentPageTitle,
    errorMessage: s.errorMessage,
    stats: { ...s.stats },
    stopRequested: s.stopRequested,
  };
}
