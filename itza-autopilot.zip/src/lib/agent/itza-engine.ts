/**
 * Playwright-based automation engine for https://www.itza.io.
 *
 * Provides high-level primitives used by the orchestrator:
 *   - launchBrowser() / closeBrowser()
 *   - login(session, email, password)
 *   - explore(session)
 *   - playQuiz(session, target)
 *   - watchVideo(session, target)
 *   - browseTrending(session, maxPages)
 *   - customBrowsingLoop(session, goal)
 *
 * Every primitive accepts the active AgentSession so it can stream progress
 * (log entries, screenshots, action updates) into the session store as it
 * runs. The engine is intentionally stateful: one shared Chromium instance
 * per server process, with a single page that persists across actions so
 * that login state survives between primitives.
 */

import { chromium, type Browser, type Page } from "playwright";
import path from "path";
import fs from "fs";
import { sessionStore, type AgentSession } from "./sessions";
import { answerQuizQuestion, decideNextAction } from "./llm-planner";

const ITZA_BASE = "https://www.itza.io";
const ITZA_HOSTS = new Set(["itza.io", "www.itza.io"]);
const SCREENSHOTS_DIR = path.join(process.cwd(), "public", "screenshots");

let browserPromise: Promise<Browser> | null = null;
let activePage: Page | null = null;
let screenshotsDirReady = false;

/**
 * Security gate: only allow navigation to itza.io.
 * Rejects anything else (SSRF / data-exfil protection against LLM-injected URLs).
 */
function sanitizeItzaUrl(raw: string): string | null {
  if (!raw || typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  try {
    // Allow relative URLs
    if (trimmed.startsWith("/")) return ITZA_BASE + trimmed;
    if (!/^https?:\/\//i.test(trimmed)) return ITZA_BASE + "/" + trimmed;
    const u = new URL(trimmed);
    if (!ITZA_HOSTS.has(u.hostname.toLowerCase())) return null;
    // Normalise to https://www.itza.io
    u.protocol = "https:";
    u.hostname = "www.itza.io";
    return u.toString();
  } catch {
    return null;
  }
}

async function ensureScreenshotsDir(): Promise<void> {
  if (screenshotsDirReady) return;
  await fs.promises.mkdir(SCREENSHOTS_DIR, { recursive: true });
  screenshotsDirReady = true;
}

async function ensureBrowser(): Promise<Browser> {
  // If we have a cached promise, validate the browser is still connected
  if (browserPromise) {
    try {
      const b = await browserPromise;
      if (b.isConnected()) return b;
      // Stale — fall through and relaunch
      browserPromise = null;
      activePage = null;
    } catch {
      browserPromise = null;
      activePage = null;
    }
  }
  browserPromise = chromium.launch({
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-blink-features=AutomationControlled",
      "--disable-dev-shm-usage",
      "--mute-audio",
    ],
  });
  browserPromise.then((b) => {
    b.on("disconnected", () => {
      browserPromise = null;
      activePage = null;
    });
  });
  return browserPromise;
}

// Clean up Chromium on server shutdown so we don't orphan processes.
// Guard with globalThis so dev-mode hot reloads don't stack listeners
// (each module re-evaluation would otherwise add a new once() handler).
const gProc = globalThis as unknown as { __itzaShutdownHooked?: boolean };
if (!gProc.__itzaShutdownHooked) {
  gProc.__itzaShutdownHooked = true;
  for (const sig of ["SIGTERM", "SIGINT"] as const) {
    process.once(sig, () => {
      void closeBrowser().finally(() => process.exit(0));
    });
  }
}

export async function ensurePage(): Promise<Page> {
  const browser = await ensureBrowser();
  if (!activePage || activePage.isClosed()) {
    const context = await browser.newContext({
      viewport: { width: 1366, height: 850 },
      userAgent:
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
      locale: "en-GB",
    });
    // itza.io is a heavy Next.js site — TTFB ~0.4s but full load can take 30s+.
    // Use a generous default timeout so navigation doesn't fail prematurely.
    context.setDefaultTimeout(45000);
    context.setDefaultNavigationTimeout(45000);
    activePage = await context.newPage();
    // Auto-navigate to itza.io on first page creation so the user sees
    // something immediately when the dashboard loads (instead of about:blank).
    void (async () => {
      try {
        await gotoWithRetry(activePage!, ITZA_BASE);
        await sleep(2500);
        await dismissCookieBanner(activePage!);
      } catch {
        /* ignore — the user can navigate manually */
      }
    })();
  }
  return activePage;
}

/** Public wrapper around the internal screenshot helper for external callers. */
export async function takeScreenshot(
  sessionId: string,
  caption: string,
  actionIndex?: number,
): Promise<void> {
  await snapshot(sessionId, caption, actionIndex);
}

/** Allow the orchestrator to query the current page state. */
export async function currentPageInfo(): Promise<{ url: string; title: string }> {
  return getCurrentPageInfo();
}

/* ─────────────────── Manual control primitives ─────────────────── */
/* These let the user drive the same Playwright browser that the agent uses,
   so manual sign-in persists when the agent takes over. */

/**
 * Capture the current page as a PNG buffer (for streaming to the client).
 * Does NOT save to disk — used for the live interactive browser view.
 *
 * If the page is mid-navigation or the browser is still launching, returns
 * null quickly (within 5s) so the caller can return a placeholder instead
 * of hanging the HTTP request.
 */
export async function captureScreenshotBuffer(): Promise<Buffer | null> {
  try {
    // If the browser is still launching, don't wait for it — return null
    // immediately so the caller returns a placeholder. The next refresh
    // cycle (800ms later) will try again.
    if (browserPromise) {
      let browser: Browser;
      try {
        browser = await Promise.race([
          browserPromise,
          new Promise<Browser>((_, reject) =>
            setTimeout(() => reject(new Error("browser launch timeout")), 4000),
          ),
        ]);
      } catch {
        return null; // Browser still launching — return placeholder
      }
      if (!browser.isConnected()) return null;
    }
    if (!activePage || activePage.isClosed()) {
      // Page doesn't exist yet — trigger creation but don't wait for it.
      // Return null; the next refresh will capture the screenshot.
      void ensurePage();
      return null;
    }
    // Wait briefly for any in-progress navigation to settle
    try {
      await activePage.waitForLoadState("domcontentloaded", { timeout: 3000 });
    } catch {
      // Timeout is fine — capture whatever is on screen
    }
    // Use JPEG with quality 70 for smaller files (~100-200KB instead of
    // 1.4MB PNG). This is critical for mobile networks where a 1.4MB
    // screenshot would take too long to load and cause timeouts.
    return await activePage.screenshot({
      type: "jpeg",
      quality: 70,
      fullPage: false,
      timeout: 5000,
    });
  } catch {
    return null;
  }
}

/**
 * Get the active page without blocking. Returns null if the browser is
 * still launching or the page doesn't exist yet. All manual control
 * functions use this to avoid hanging the HTTP request.
 */
async function getActivePageQuickly(): Promise<Page | null> {
  // If the browser is still launching, wait max 3s
  if (browserPromise) {
    let browser: Browser;
    try {
      browser = await Promise.race([
        browserPromise,
        new Promise<Browser>((_, reject) =>
          setTimeout(() => reject(new Error("timeout")), 3000),
        ),
      ]);
    } catch {
      return null; // Browser still launching
    }
    if (!browser.isConnected()) return null;
  }
  if (!activePage || activePage.isClosed()) {
    // Page doesn't exist yet — trigger creation in the background
    void ensurePage();
    return null;
  }
  return activePage;
}

/**
 * Click at the given coordinates in the page. Used for manual control.
 * Returns a friendly error if the browser is still launching.
 */
export async function clickAt(x: number, y: number): Promise<{ ok: boolean; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) {
      return { ok: false, error: "Browser is still launching. Please wait a few seconds and try again." };
    }
    await page.mouse.click(x, y);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Type text into the currently focused element. Used for manual control.
 */
export async function typeText(text: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) {
      return { ok: false, error: "Browser is still launching. Please wait a few seconds and try again." };
    }
    await page.keyboard.type(text, { delay: 30 });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Press a single key (e.g. "Enter", "Tab", "Backspace").
 */
export async function pressKey(key: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) {
      return { ok: false, error: "Browser is still launching." };
    }
    await page.keyboard.press(key);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Navigate the shared browser to a URL (manual control).
 */
export async function manualNavigate(url: string): Promise<{ ok: boolean; url?: string; title?: string; error?: string }> {
  try {
    const safe = sanitizeItzaUrl(url);
    if (!safe) return { ok: false, error: "Only itza.io URLs are allowed" };
    // For navigate, we DO want to wait for the browser to be ready
    const page = await ensurePage();
    await gotoWithRetry(page, safe);
    await sleep(2500);
    await dismissCookieBanner(page);
    return {
      ok: true,
      url: page.url(),
      title: await page.title().catch(() => ""),
    };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Go back in browser history.
 */
export async function goBack(): Promise<{ ok: boolean; url?: string; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) return { ok: false, error: "Browser is still launching." };
    await page.goBack({ waitUntil: "commit", timeout: 30000 }).catch(() => {});
    await sleep(1500);
    return { ok: true, url: page.url() };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Go forward in browser history.
 */
export async function goForward(): Promise<{ ok: boolean; url?: string; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) return { ok: false, error: "Browser is still launching." };
    await page.goForward({ waitUntil: "commit", timeout: 30000 }).catch(() => {});
    await sleep(1500);
    return { ok: true, url: page.url() };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Reload the current page.
 */
export async function reload(): Promise<{ ok: boolean; url?: string; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) return { ok: false, error: "Browser is still launching." };
    await page.reload({ waitUntil: "commit", timeout: 45000 }).catch(() => {});
    await sleep(2500);
    await dismissCookieBanner(page);
    return { ok: true, url: page.url() };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/**
 * Scroll the page in a direction.
 */
export async function scrollPage(direction: "up" | "down"): Promise<{ ok: boolean; error?: string }> {
  try {
    const page = await getActivePageQuickly();
    if (!page) return { ok: false, error: "Browser is still launching." };
    await page.evaluate(
      direction === "up"
        ? () => window.scrollBy(0, -window.innerHeight * 0.7)
        : () => window.scrollBy(0, window.innerHeight * 0.7),
    );
    return { ok: true };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

export async function closeBrowser(): Promise<void> {
  if (browserPromise) {
    try {
      const b = await browserPromise;
      await b.close();
    } catch {
      /* ignore */
    }
    browserPromise = null;
    activePage = null;
  }
}

function ssPath(sessionId: string, label: string): string {
  const safe = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40);
  const name = `${sessionId}_${Date.now().toString(36)}_${safe}.png`;
  return path.join(SCREENSHOTS_DIR, name);
}

function ssPublicPath(absPath: string): string {
  return "/screenshots/" + path.basename(absPath);
}

async function snapshot(
  sessionId: string,
  caption: string,
  actionIndex?: number,
): Promise<void> {
  try {
    const page = await ensurePage();
    const abs = ssPath(sessionId, caption);
    await ensureScreenshotsDir();
    await page.screenshot({ path: abs, fullPage: false });
    sessionStore.addScreenshot(sessionId, ssPublicPath(abs), caption, actionIndex);
  } catch (err) {
    sessionStore.log(sessionId, "warn", `Screenshot failed: ${(err as Error).message}`);
  }
}

async function withAction<T>(
  sessionId: string,
  index: number,
  description: string,
  fn: () => Promise<T>,
): Promise<T | undefined> {
  const action = sessionStore.get(sessionId)?.plan[index];
  if (!action) return undefined;
  sessionStore.update(sessionId, {});
  action.status = "running";
  action.startedAt = Date.now();
  sessionStore.log(sessionId, "info", `▶ ${description}`);
  try {
    const result = await fn();
    action.status = "done";
    action.finishedAt = Date.now();
    const s = sessionStore.get(sessionId);
    if (s) s.stats.actionsCompleted += 1;
    sessionStore.log(sessionId, "success", `✓ ${description}`);
    return result;
  } catch (err) {
    action.status = "error";
    action.finishedAt = Date.now();
    action.detail = (err as Error).message;
    sessionStore.log(
      sessionId,
      "error",
      `✗ ${description}: ${(err as Error).message}`,
    );
    throw err;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

async function safeClickByText(page: Page, text: string): Promise<boolean> {
  const candidates = [
    `text="${text}"`,
    `text=${text}`,
    `a:has-text("${text}")`,
    `button:has-text("${text}")`,
  ];
  for (const sel of candidates) {
    try {
      const el = page.locator(sel).first();
      if ((await el.count()) > 0 && (await el.isVisible())) {
        await el.click({ timeout: 5000 });
        return true;
      }
    } catch {
      /* try next */
    }
  }
  return false;
}

async function safeClickHref(page: Page, hrefSubstr: string): Promise<boolean> {
  try {
    const el = page.locator(`a[href*="${hrefSubstr}"]`).first();
    if ((await el.count()) > 0) {
      await el.click({ timeout: 5000 });
      return true;
    }
  } catch {
    /* ignore */
  }
  return false;
}

/**
 * Dismiss cookie consent / banner dialogs that block scrolling on itza.io.
 * Call this after every page.goto() on itza.io.
 *
 * IMPORTANT: itza.io's cookie banner has a "Close" button AND a "Cookie Policy"
 * link. We must click the actual close button (usually an X icon or a button
 * inside the banner), NOT the "Cookie Policy" link which navigates away.
 */
async function dismissCookieBanner(page: Page): Promise<boolean> {
  try {
    // Strategy 1: Look for a button/link inside a cookie/banner/consent
    // container whose text is exactly "Close" (not "Cookie Policy").
    const closed = await page
      .evaluate(() => {
        // Find cookie banner containers by common class/role patterns
        const bannerSelectors = [
          '[class*="cookie" i]',
          '[class*="banner" i]',
          '[class*="consent" i]',
          '[id*="cookie" i]',
          '[id*="banner" i]',
          '[role="dialog"]',
        ];
        const banners = new Set<Element>();
        for (const sel of bannerSelectors) {
          document.querySelectorAll(sel).forEach((el) => banners.add(el));
        }
        // Also check for elements containing "cookie" text
        const all = document.querySelectorAll("div, section, aside, footer");
        for (const el of all) {
          const t = (el.textContent || "").toLowerCase();
          if (
            t.length < 500 &&
            (t.includes("cookie") || t.includes("consent")) &&
            t.includes("close")
          ) {
            banners.add(el);
          }
        }
        // In each banner, find a "Close" button (exact match, not "Cookie Policy")
        for (const banner of banners) {
          const buttons = banner.querySelectorAll("button, a, [role=button]");
          for (const btn of buttons) {
            const t = (btn.textContent || "").trim().toLowerCase();
            if (t === "close" || t === "accept" || t === "got it" || t === "ok" || t === "accept all" || t === "i agree") {
              (btn as HTMLElement).click();
              return true;
            }
          }
          // Also check for an X button (aria-label or title)
          const xBtns = banner.querySelectorAll('button[aria-label*="close" i], button[title*="close" i]');
          for (const btn of xBtns) {
            (btn as HTMLElement).click();
            return true;
          }
        }
        return false;
      })
      .catch(() => false);
    if (closed) {
      await sleep(400);
      return true;
    }
  } catch {
    /* ignore */
  }
  return false;
}

/**
 * Navigate to a URL with retry logic. itza.io can intermittently return
 * ERR_ABORTED (redirect chain / service worker) or timeout under load.
 * We retry up to 3 times with increasing waits.
 */
async function gotoWithRetry(
  page: Page,
  url: string,
  retries = 3,
): Promise<void> {
  let lastErr: unknown = null;
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      await page.goto(url, { waitUntil: "commit", timeout: 45000 });
      return;
    } catch (err) {
      lastErr = err;
      const msg = (err as Error).message;
      // If the page actually loaded despite the error (common with ERR_ABORTED
      // caused by client-side redirects), check if we're on a valid page
      try {
        const currentUrl = page.url();
        if (currentUrl && !currentUrl.includes("about:blank")) {
          // Page is actually loaded — treat as success
          return;
        }
      } catch {
        /* ignore */
      }
      if (attempt < retries - 1) {
        await sleep(2000 * (attempt + 1));
      }
    }
  }
  throw lastErr;
}

async function getCurrentPageInfo(): Promise<{ url: string; title: string }> {
  // Use the quick version so the state endpoint doesn't block while the
  // browser is launching.
  const page = await getActivePageQuickly();
  if (!page) return { url: "", title: "" };
  return {
    url: page.url(),
    title: await page.title().catch(() => ""),
  };
}

async function recordCurrentPage(sessionId: string): Promise<void> {
  const info = await getCurrentPageInfo();
  sessionStore.update(sessionId, {
    currentPageUrl: info.url,
    currentPageTitle: info.title,
  });
}

/* ────────────────────────────── LOGIN ────────────────────────────── */

export async function login(
  sessionId: string,
  actionIndex: number,
  email: string,
  password: string,
): Promise<boolean> {
  const desc = `Sign in to ITZA as ${email}`;
  try {
    await withAction(sessionId, actionIndex, desc, async () => {
      if (sessionStore.get(sessionId)?.stopRequested) {
        throw new Error("Stopped before login");
      }
      const page = await ensurePage();
      // Try direct sign-in URL first
      await gotoWithRetry(page, `${ITZA_BASE}/sign-in`);
      await sleep(3500);
      // If /sign-in 404s, fall back to clicking the Sign In button on homepage
      if (page.url().includes("/404") || (await page.title()).toLowerCase().includes("not found")) {
        await gotoWithRetry(page, ITZA_BASE);
        await sleep(3500);
        await safeClickByText(page, "Sign In");
      }
      await sleep(2000);
      await snapshot(sessionId, "Sign-in page", actionIndex);

      // Locate email + password fields
      const emailLocator =
        page.locator('input[type="email"]').first();
      const passwordLocator =
        page.locator('input[type="password"]').first();
      if ((await emailLocator.count()) === 0) {
        throw new Error("Could not find email input on sign-in page");
      }
      await emailLocator.fill(email);
      if ((await passwordLocator.count()) > 0 && password) {
        await passwordLocator.fill(password);
      }
      await sleep(400);
      await snapshot(sessionId, "Credentials filled", actionIndex);

      // Try several submit strategies
      const submitted =
        (await safeClickByText(page, "Sign In")) ||
        (await safeClickByText(page, "Sign in")) ||
        (await safeClickByText(page, "Log in")) ||
        (await safeClickByText(page, "Log In")) ||
        (await page.keyboard.press("Enter").then(() => true));
      await sleep(2500);
      await recordCurrentPage(sessionId);
      await snapshot(sessionId, "After sign-in", actionIndex);
      // Heuristic: presence of "My ITZA" link or absence of "Sign In" => success
      const body = (await page.content()).toLowerCase();
      const looksLoggedIn =
        body.includes("sign out") ||
        body.includes("log out") ||
        (body.includes("my itza") && !body.includes("sign in"));
      if (!looksLoggedIn) {
        sessionStore.log(
          sessionId,
          "warn",
          "Sign-in may not have succeeded — continuing in current session state.",
        );
      }
      return submitted;
    });
    return true;
  } catch {
    return false;
  }
}

/* ────────────────────────────── NAVIGATE ────────────────────────────── */

/**
 * Navigate to a URL (must be on itza.io). Uses withAction for consistent
 * error handling, stats and screenshots.
 */
export async function navigateTo(
  sessionId: string,
  actionIndex: number,
  target?: string,
): Promise<void> {
  const rawUrl = target || ITZA_BASE;
  const safeUrl = sanitizeItzaUrl(rawUrl) ?? ITZA_BASE;
  const desc = `Navigate to ${safeUrl}`;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    await gotoWithRetry(page, safeUrl);
    // Wait for JS to render content (itza.io is a heavy Next.js site)
    await sleep(3500);
    // Dismiss cookie banner if present
    await dismissCookieBanner(page);
    await recordCurrentPage(sessionId);
    const s = sessionStore.get(sessionId);
    const caption = `Navigated: ${s?.currentPageTitle || safeUrl}`.slice(0, 80);
    await snapshot(sessionId, caption, actionIndex);
  });
}

/* ────────────────────────────── EXPLORE ────────────────────────────── */

export async function explore(
  sessionId: string,
  actionIndex: number,
): Promise<void> {
  const desc = "Explore ITZA homepage and catalogue quizzes, courses and videos";
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    await gotoWithRetry(page, ITZA_BASE);
    // itza.io is a heavy Next.js site — give it time to render JS
    await sleep(4000);

    // Close the cookie consent banner if present — it blocks scrolling
    if (await dismissCookieBanner(page)) {
      sessionStore.log(sessionId, "info", "Closed cookie consent banner.");
    }

    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "Homepage", actionIndex);

    // Scroll through homepage FIRST so all lazy-loaded content is rendered
    for (let i = 0; i < 6; i++) {
      await page.evaluate(() =>
        window.scrollBy(0, window.innerHeight * 0.8),
      );
      await sleep(800);
    }
    // Scroll back to top
    await page.evaluate(() => window.scrollTo(0, 0));
    await sleep(500);

    // Collect ALL links on the homepage (courses, quizzes, stories, etc.)
    // Retry up to 3 times with a wait between each, in case content is still
    // loading lazily.
    let hrefs: { href: string; text: string }[] = [];
    for (let attempt = 0; attempt < 3; attempt++) {
      hrefs = await page.evaluate(() => {
        const origin = location.origin;
        const links = Array.from(document.querySelectorAll("a[href]"));
        const seen = new Set<string>();
        const out: { href: string; text: string }[] = [];
        for (const a of links) {
          const href = (a as HTMLAnchorElement).href;
          const text = (a.textContent || "").trim();
          if (!href || !href.startsWith(origin)) continue;
          if (seen.has(href)) continue;
          seen.add(href);
          const lower = text.toLowerCase();
          if (
            lower === "sign in" ||
            lower === "sign up" ||
            lower === "my itza" ||
            lower === "explore" ||
            lower === "store" ||
            lower === "privacy" ||
            lower === "cookies" ||
            lower === "terms & conditions" ||
            lower === "ai policy" ||
            lower === "help" ||
            lower === "feedback" ||
            lower === "contact" ||
            lower === "" ||
            lower.startsWith("close")
          ) {
            continue;
          }
          out.push({ href, text: text.slice(0, 80) });
        }
        return out.slice(0, 40);
      });
      if (hrefs.length >= 3) break; // got enough, stop retrying
      await sleep(2000);
    }

    // Also collect visible text content (course/quiz names) as a fallback —
    // itza.io might render course cards as divs/buttons without <a> tags.
    const visibleContent = await page
      .evaluate(() => {
        const all = Array.from(
          document.querySelectorAll("h1,h2,h3,h4,h5,p,div,span,button"),
        );
        const texts = new Set<string>();
        for (const el of all) {
          const t = (el.textContent || "").trim();
          if (t.length < 3 || t.length > 120) continue;
          // Look for course/quiz/topic-like text
          if (
            /quiz|challenge|course|ocean|egypt|dolphin|hip\s*hop|indigo|money|football|cricket|wild\s*wisdom|universe|alien|moon|arora/i.test(
              t,
            )
          ) {
            // Only add if this is a "leaf" text (no child elements with text)
            const childText = Array.from(el.children)
              .map((c) => (c.textContent || "").trim())
              .join("");
            if (childText.length < t.length * 0.5) {
              texts.add(t.slice(0, 100));
            }
          }
        }
        return Array.from(texts).slice(0, 30);
      })
      .catch(() => [] as string[]);

    sessionStore.log(
      sessionId,
      "info",
      `Found ${hrefs.length} links and ${visibleContent.length} content items on homepage.`,
    );
    if (hrefs.length > 0) {
      sessionStore.log(
        sessionId,
        "info",
        `Links: ${hrefs.slice(0, 10).map((h) => h.text || h.href).join(" · ")}`,
      );
    }
    if (visibleContent.length > 0) {
      sessionStore.log(
        sessionId,
        "info",
        `Content: ${visibleContent.slice(0, 10).join(" · ")}`,
      );
    }
    await snapshot(sessionId, "Homepage (scrolled)", actionIndex);
  });
}

/* ────────────────────────────── PLAY QUIZ ────────────────────────────── */

const DEFAULT_QUIZ_URLS = [
  "/course/cricket-quiz-competition",
  "/course/lords-quiz-challenge",
  "/course/wild-wisdom-global-challenge",
  "/course/ocean-odyssey",
];

async function resolveCourseUrl(
  page: Page,
  target: string | undefined,
  defaults: string[],
): Promise<string> {
  if (target) {
    // Security: only allow itza.io URLs
    const sanitized = sanitizeItzaUrl(target);
    if (sanitized) return sanitized;
    // Target didn't pass sanitization — try to find a matching link on the homepage
    const slug = target.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    await gotoWithRetry(page, ITZA_BASE).catch(() => {});
    await sleep(800);
    const match = await page
      .evaluate((q: string) => {
        const a = Array.from(document.querySelectorAll("a[href]")).find((el) => {
          const t = (el.textContent || "").toLowerCase();
          const h = (el as HTMLAnchorElement).href.toLowerCase();
          return t.includes(q) || h.includes(q);
        });
        return a ? (a as HTMLAnchorElement).href : null;
      }, slug)
      .catch(() => null);
    if (match) return match;
    return `${ITZA_BASE}/course/${slug}`;
  }
  // No target: try each default URL until one returns 200-ish
  for (const u of defaults) {
    const full = u.startsWith("http") ? u : ITZA_BASE + u;
    try {
      const resp = await gotoWithRetry(page, full);
      if (resp && resp.ok()) return full;
    } catch {
      /* try next */
    }
  }
  return ITZA_BASE + defaults[0];
}

// Navigation/button texts that are NEVER quiz answers.
const NAV_BUTTON_PATTERNS =
  /^(start(\s+quiz)?!?|begin|continue|next(\s+question)?|submit|finish|skip|back|cancel|sign\s*in|sign\s*up|log\s*in|log\s*out|home|menu|close|got\s*it|ok|okay|play|watch|learn\s*more|explore|get\s*started|enter|see\s*all|check\s*out|feedback|help|privacy|cookies|terms)$/i;

export async function playQuiz(
  sessionId: string,
  actionIndex: number,
  target?: string,
): Promise<{ questionsAnswered: number }> {
  const desc = `Play quiz${target ? `: ${target}` : ""}`;
  let answered = 0;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    const url = await resolveCourseUrl(page, target, DEFAULT_QUIZ_URLS);
    sessionStore.log(sessionId, "info", `Resolved quiz URL: ${url}`);
    await gotoWithRetry(page, url);
    await sleep(4000);
    await dismissCookieBanner(page);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "Quiz landing page", actionIndex);

    // STEP 1: Click "Start Quiz" / "Start" / "Begin" to ENTER the quiz.
    sessionStore.log(sessionId, "info", "Looking for Start button to begin quiz…");
    const startClicked =
      (await safeClickByText(page, "Start Quiz!")) ||
      (await safeClickByText(page, "Start Quiz")) ||
      (await safeClickByText(page, "Start")) ||
      (await safeClickByText(page, "Begin")) ||
      (await safeClickByText(page, "Get Started")) ||
      (await safeClickByText(page, "Get started"));
    if (startClicked) {
      sessionStore.log(sessionId, "success", "Clicked Start to enter the quiz.");
    } else {
      sessionStore.log(sessionId, "warn", "No Start button found — may already be inside the quiz.");
    }
    await sleep(2500);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "After clicking Start", actionIndex);

    // STEP 2: Check for login wall. ITZA gates quizzes behind auth.
    const pageText = await page
      .evaluate(() => document.body.innerText || "")
      .catch(() => "");
    const needsLogin =
      /log\s*in\s*to\s*(take|play|see)/i.test(pageText) ||
      /please\s*log\s*in/i.test(pageText) ||
      /sign\s*in\s*to\s*(take|play|see)/i.test(pageText);
    if (needsLogin) {
      sessionStore.log(
        sessionId,
        "error",
        "LOGIN REQUIRED: This quiz needs you to be signed in. Provide ITZA credentials (tick 'Attach ITZA credentials') and use a 'login' step BEFORE the quiz step. The agent cannot answer quiz questions without authentication.",
      );
      await snapshot(sessionId, "Login wall detected", actionIndex);
      return;
    }

    // STEP 3: Answer up to 30 questions in a loop.
    for (let q = 0; q < 30; q++) {
      if (sessionStore.get(sessionId)?.stopRequested) {
        sessionStore.log(sessionId, "warn", "Stop requested — exiting quiz loop.");
        break;
      }

      const currentText = await page
        .evaluate(() => document.body.innerText || "")
        .catch(() => "");

      // Check for definitive end-of-quiz markers FIRST. Require an actual
      // score number, not just the word "results".
      const scoreMatch = currentText.match(/\d+\s*\/\s*\d+|score\s*[:=]?\s*\d+|you\s+scored/i);
      const hasResults =
        (scoreMatch && /score|result|congratulations|well\s*done/i.test(currentText)) ||
        /quiz\s+complete|you\s+have\s+finished/i.test(currentText);
      if (hasResults && q > 0) {
        sessionStore.log(sessionId, "success", `Quiz results screen reached after ${answered} question(s).`);
        await snapshot(sessionId, "Quiz results", actionIndex);
        break;
      }

      // Detect clickable options on the current screen.
      const qData = await page
        .evaluate(() => {
          const optionEls = Array.from(
            document.querySelectorAll(
              'button, [role="button"], label, li, a, [role="option"], [role="radio"]',
            ),
          );
          const options: { text: string; tag: string }[] = [];
          for (const el of optionEls) {
            const t = (el.textContent || "").trim();
            if (t.length < 1 || t.length > 200) continue;
            const r = (el as HTMLElement).getBoundingClientRect();
            if (r.width < 60 || r.height < 20) continue;
            const parent = (el as HTMLElement).closest("nav, header, footer");
            if (parent) continue;
            options.push({ text: t.slice(0, 200), tag: el.tagName });
            if (options.length >= 12) break;
          }
          return { options };
        })
        .catch(() => ({ options: [] as { text: string; tag: string }[] }));

      let realOptions = (qData.options || []).filter(
        (o) => !NAV_BUTTON_PATTERNS.test(o.text),
      );
      realOptions = realOptions.filter((o) => o.text.length <= 100);

      if (realOptions.length < 2) {
        const advanced =
          (await safeClickByText(page, "Next")) ||
          (await safeClickByText(page, "Next question")) ||
          (await safeClickByText(page, "Continue")) ||
          (await safeClickByText(page, "Submit")) ||
          (await safeClickByText(page, "Finish"));
        if (advanced) {
          sessionStore.log(
            sessionId,
            "info",
            "No question on this screen — clicked Next/Continue to advance.",
          );
          await sleep(1500);
          continue;
        }
        if (q === 0) {
          sessionStore.log(
            sessionId,
            "warn",
            "No quiz questions detected on this page. The quiz may require login, may have changed layout, or may not have started. Check the screenshot.",
          );
        } else {
          sessionStore.log(
            sessionId,
            "info",
            `Finished after ${answered} question(s) — no more questions detected.`,
          );
        }
        await snapshot(sessionId, `Quiz state (Q${q + 1})`, actionIndex);
        break;
      }

      const questionText = await page
        .evaluate(() => {
          const candidates = Array.from(
            document.querySelectorAll("h1,h2,h3,h4,h5,p,div,span"),
          );
          let best = "";
          for (const el of candidates) {
            const t = (el.textContent || "").trim();
            if (t.length < 10 || t.length > 400) continue;
            const r = (el as HTMLElement).getBoundingClientRect();
            if (r.width < 200 || r.top > 500) continue;
            if (t.includes("?") && t.length > best.length) {
              best = t;
            }
          }
          if (!best) {
            for (const el of candidates) {
              const t = (el.textContent || "").trim();
              if (t.length < 15 || t.length > 300) continue;
              const r = (el as HTMLElement).getBoundingClientRect();
              if (r.width < 200 || r.top > 400) continue;
              if (/sign|cookie|start\s*quiz|terms|privacy/i.test(t)) continue;
              if (t.length > best.length) best = t;
            }
          }
          return best.slice(0, 400);
        })
        .catch(() => "");

      const opts = realOptions.map((o) => o.text);
      sessionStore.log(
        sessionId,
        "info",
        `Q${q + 1}: ${questionText.slice(0, 100) || "(question text not isolated)"} → ${opts.length} options: ${opts.map((o) => o.slice(0, 30)).join(" | ")}`,
      );

      const decision = await answerQuizQuestion(
        questionText || currentText.slice(0, 600),
        opts,
      );
      const chosenText = opts[decision.answerIndex] || "";
      sessionStore.log(
        sessionId,
        "info",
        `→ Answering Q${q + 1}: "${chosenText.slice(0, 50)}" (${decision.reasoning})`,
      );

      const clicked = await page
        .evaluate((txt: string) => {
          const els = Array.from(
            document.querySelectorAll(
              'button, [role="button"], label, li, a, [role="option"], [role="radio"]',
            ),
          ).filter((el) => {
            const t = (el.textContent || "").trim();
            const r = el.getBoundingClientRect();
            return (
              t.length > 0 &&
              t.length <= 200 &&
              r.width > 60 &&
              r.height > 20 &&
              !el.closest("nav, header, footer")
            );
          });
          const target = els.find((el) => (el.textContent || "").trim() === txt);
          if (!target) return false;
          (target as HTMLElement).click();
          return true;
        }, chosenText)
        .catch(() => false);

      if (!clicked) {
        sessionStore.log(
          sessionId,
          "warn",
          `Could not click option "${chosenText.slice(0, 40)}" — trying Next to advance.`,
        );
      } else {
        answered += 1;
        const s = sessionStore.get(sessionId);
        if (s) s.stats.quizzesAnswered += 1;
      }

      await sleep(1000);
      await snapshot(sessionId, `Q${q + 1} answered`, actionIndex);

      const advanced =
        (await safeClickByText(page, "Next")) ||
        (await safeClickByText(page, "Next question")) ||
        (await safeClickByText(page, "Submit")) ||
        (await safeClickByText(page, "Continue")) ||
        (await safeClickByText(page, "Finish"));
      await sleep(1500);
      if (advanced) continue;

      const endText = await page
        .evaluate(() => document.body.innerText || "")
        .catch(() => "");
      if (
        /\d+\s*\/\s*\d+|score\s*[:=]?\s*\d+|you\s+scored|quiz\s+complete/i.test(endText)
      ) {
        sessionStore.log(sessionId, "success", `Quiz results screen reached after ${answered} question(s).`);
        await snapshot(sessionId, "Quiz results", actionIndex);
        break;
      }
    }
  });
  return { questionsAnswered: answered };
}


/* ────────────────────────────── WATCH VIDEO ────────────────────────────── */

const DEFAULT_VIDEO_URLS = [
  "/course/ocean-odyssey",
  "/course/egypt",
  "/course/hip-hop-holiday",
  "/course/indigo-journeys",
  "/course/dolphins",
];

export async function watchVideo(
  sessionId: string,
  actionIndex: number,
  target?: string,
): Promise<{ videosPlayed: number }> {
  const desc = `Watch video course${target ? `: ${target}` : ""}`;
  let played = 0;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    const url = await resolveCourseUrl(page, target, DEFAULT_VIDEO_URLS);
    sessionStore.log(sessionId, "info", `Resolved course URL: ${url}`);
    await gotoWithRetry(page, url);
    await sleep(4000);
    await dismissCookieBanner(page);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "Course landing", actionIndex);

    // Start course
    const startClicked =
      (await safeClickByText(page, "Start")) ||
      (await safeClickByText(page, "Begin")) ||
      (await safeClickByText(page, "Continue")) ||
      (await safeClickByText(page, "Watch")) ||
      (await safeClickByText(page, "Get started"));
    await sleep(2000);
    await snapshot(sessionId, "Course started", actionIndex);

    // Iterate up to 15 video screens
    for (let v = 0; v < 15; v++) {
      if (sessionStore.get(sessionId)?.stopRequested) {
        sessionStore.log(sessionId, "warn", "Stop requested — exiting video loop.");
        break;
      }
      // Try to find and play a <video>
      const videoInfo = await page
        .evaluate(() => {
          const vids = Array.from(document.querySelectorAll("video"));
          if (vids.length === 0) return null;
          const v = vids[0] as HTMLVideoElement;
          // Force-play, muted to bypass autoplay restrictions
          v.muted = true;
          v.play().catch(() => {});
          return {
            duration: v.duration || 0,
            current: v.currentTime || 0,
          };
        })
        .catch(() => null);

      if (videoInfo) {
        played += 1;
        const s = sessionStore.get(sessionId);
        if (s) s.stats.videosWatched += 1;
        sessionStore.log(
          sessionId,
          "info",
          `Video ${v + 1}: duration=${Math.round(videoInfo.duration)}s — playing (muted, fast-forwarded).`,
        );
        // Fast-forward: jump near the end, then let it finish
        await page
          .evaluate(() => {
            const v = document.querySelector("video") as HTMLVideoElement;
            if (v && v.duration) {
              v.currentTime = Math.max(0, v.duration - 0.5);
            }
          })
          .catch(() => {});
        await sleep(1500);
        await snapshot(sessionId, `Video ${v + 1} playing`, actionIndex);
      } else {
        // No video on this screen — take a snapshot and try to advance
        await snapshot(sessionId, `Screen ${v + 1} (no video)`, actionIndex);
      }

      // Try to advance: Next / Continue / Skip
      const advanced =
        (await safeClickByText(page, "Next")) ||
        (await safeClickByText(page, "Next section")) ||
        (await safeClickByText(page, "Continue")) ||
        (await safeClickByText(page, "Skip")) ||
        (await safeClickByText(page, "Finish"));
      await sleep(1200);
      if (!advanced) {
        sessionStore.log(
          sessionId,
          "info",
          "No Next button found — course may be complete.",
        );
        break;
      }
    }
  });
  return { videosPlayed: played };
}

/* ────────────────────────────── BROWSE ────────────────────────────── */

export async function browseTrending(
  sessionId: string,
  actionIndex: number,
  maxPages = 5,
): Promise<{ pagesVisited: number }> {
  const desc = `Browse trending stories (max ${maxPages})`;
  let visited = 0;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    await gotoWithRetry(page, ITZA_BASE);
    await sleep(4000);
    await dismissCookieBanner(page);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "Homepage for browse", actionIndex);

    // Collect "Learn More" / story links
    const links = await page.evaluate((max: number) => {
      const anchors = Array.from(document.querySelectorAll("a[href]"));
      return anchors
        .map((a) => ({
          href: (a as HTMLAnchorElement).href,
          text: (a.textContent || "").trim(),
        }))
        .filter(
          (l) =>
            l.href.startsWith(location.origin) &&
            (l.text.toLowerCase().includes("learn") ||
              l.text.toLowerCase().includes("explore") ||
              l.text.toLowerCase().includes("discover") ||
              l.text.toLowerCase().includes("start") ||
              l.href.includes("/story") ||
              l.href.includes("/course")),
        )
        .slice(0, max);
    }, maxPages);

    for (const link of links) {
      if (sessionStore.get(sessionId)?.stopRequested) break;
      try {
        await gotoWithRetry(page, link.href);
        await sleep(3500);
        await recordCurrentPage(sessionId);
        // Scroll through the story
        for (let i = 0; i < 3; i++) {
          await page.evaluate(() =>
            window.scrollBy(0, window.innerHeight * 0.8),
          );
          await sleep(700);
        }
        await snapshot(
          sessionId,
          `Visited: ${link.text.slice(0, 40) || link.href}`,
          actionIndex,
        );
        visited += 1;
        const s = sessionStore.get(sessionId);
        if (s) s.stats.pagesVisited += 1;
        sessionStore.log(
          sessionId,
          "info",
          `Visited page ${visited}: ${link.text.slice(0, 60) || link.href}`,
        );
      } catch (err) {
        sessionStore.log(
          sessionId,
          "warn",
          `Failed to visit ${link.href}: ${(err as Error).message}`,
        );
      }
    }
  });
  return { pagesVisited: visited };
}

/* ────────────────────────────── CUSTOM LLM-DRIVEN LOOP ────────────────────────────── */

export async function customBrowsingLoop(
  sessionId: string,
  actionIndex: number,
  goal: string,
): Promise<void> {
  const desc = `Custom task: ${goal.slice(0, 80)}`;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    if (!page.url().startsWith(ITZA_BASE)) {
      await gotoWithRetry(page, ITZA_BASE);
      await sleep(3500);
    }

    const recent: string[] = [];
    for (let step = 0; step < 18; step++) {
      if (sessionStore.get(sessionId)?.stopRequested) {
        sessionStore.log(sessionId, "warn", "Stop requested — exiting custom loop.");
        break;
      }
      // Build a compact snapshot of interactive elements
      const snap = await page
        .evaluate(() => {
          const els = Array.from(
            document.querySelectorAll(
              'a, button, input, textarea, select, [role="button"], [role="link"]',
            ),
          );
          return els
            .map((el, i) => {
              const r = (el as HTMLElement).getBoundingClientRect();
              if (r.width < 20 || r.height < 10) return null;
              const t = (el.textContent || "").trim().slice(0, 80);
              const aria = (el as HTMLElement).getAttribute("aria-label") || "";
              const name = t || aria || el.tagName.toLowerCase();
              return { ref: `@e${i}`, role: el.tagName.toLowerCase(), name };
            })
            .filter((x): x is { ref: string; role: string; name: string } => !!x)
            .slice(0, 80);
        })
        .catch(() => [] as { ref: string; role: string; name: string }[]);

      const decision = await decideNextAction(goal, snap, recent);
      const reason = decision.reason ? ` (${decision.reason})` : "";
      sessionStore.log(
        sessionId,
        "info",
        `Step ${step + 1}: ${decision.action}${reason}`,
      );

      if (decision.action === "done") {
        sessionStore.log(sessionId, "success", "Custom goal marked complete by LLM.");
        break;
      }
      if (decision.action === "navigate" && decision.value) {
        // Security: only allow itza.io URLs
        const safe = sanitizeItzaUrl(decision.value);
        if (!safe) {
          sessionStore.log(
            sessionId,
            "warn",
            `Refusing to navigate to non-itza URL: ${decision.value.slice(0, 80)}`,
          );
          recent.push(`navigate (blocked)`);
        } else {
          await gotoWithRetry(page, safe);
          recent.push(`navigate ${decision.value}`);
        }
      } else if (decision.action === "click" && decision.ref) {
        const idx = parseInt(decision.ref.replace("@e", ""), 10);
        if (!Number.isInteger(idx) || idx < 0 || idx >= snap.length) {
          sessionStore.log(
            sessionId,
            "warn",
            `LLM returned invalid ref ${decision.ref} — skipping.`,
          );
          recent.push(`click ${decision.ref} (invalid)`);
        } else {
          // Verify the element at that index still has the same name as when
          // we snapshotted it — guards against DOM shifts between snapshot
          // and click.
          const expectedName = snap[idx].name;
          const clicked = await page
            .evaluate(
              (i: number, expected: string) => {
                const els = Array.from(
                  document.querySelectorAll(
                    'a, button, input, textarea, select, [role="button"], [role="link"]',
                  ),
                );
                const t = els[i] as HTMLElement | undefined;
                if (!t) return false;
                const r = t.getBoundingClientRect();
                if (r.width < 20 || r.height < 10) return false;
                const currentName =
                  (t.textContent || "").trim().slice(0, 80) ||
                  t.getAttribute("aria-label") ||
                  "";
                if (expected && currentName && currentName !== expected) {
                  return false; // DOM shifted
                }
                t.click();
                return true;
              },
              idx,
              expectedName,
            )
            .catch(() => false);
          recent.push(
            clicked
              ? `click ${decision.ref}`
              : `click ${decision.ref} (stale/failed)`,
          );
          if (!clicked) {
            sessionStore.log(
              sessionId,
              "warn",
              `Click on ${decision.ref} failed (element gone or shifted).`,
            );
          }
        }
      } else if (decision.action === "fill" && decision.ref && decision.value) {
        const idx = parseInt(decision.ref.replace("@e", ""), 10);
        if (!Number.isInteger(idx) || idx < 0) {
          sessionStore.log(sessionId, "warn", `Fill: invalid ref ${decision.ref}`);
        } else {
          await page
            .evaluate(
              (i: number, val: string) => {
                const els = Array.from(
                  document.querySelectorAll("input, textarea"),
                );
                const t = els[i] as HTMLInputElement | null;
                if (t) {
                  t.value = val;
                  t.dispatchEvent(new Event("input", { bubbles: true }));
                  t.dispatchEvent(new Event("change", { bubbles: true }));
                }
              },
              idx,
              decision.value,
            )
            .catch(() => {});
          recent.push(`fill ${decision.ref}`);
        }
      } else if (decision.action === "scroll") {
        await page.evaluate(
          decision.value === "up"
            ? () => window.scrollBy(0, -window.innerHeight * 0.6)
            : () => window.scrollBy(0, window.innerHeight * 0.6),
        );
        recent.push(`scroll ${decision.value || "down"}`);
      }

      await sleep(2500);
      await recordCurrentPage(sessionId);
      if (step % 2 === 0) {
        await snapshot(sessionId, `Custom step ${step + 1}`, actionIndex);
      }
    }
  });
}
