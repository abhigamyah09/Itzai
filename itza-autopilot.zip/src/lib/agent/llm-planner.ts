/**
 * LLM task planner and quiz answerer using z-ai-web-dev-sdk.
 *
 * Responsibilities:
 *   1. planTask(prompt, context) — turn a natural-language task into an
 *      ordered list of high-level agent actions (navigate, login, play_quiz,
 *      watch_video, browse, custom).
 *   2. answerQuizQuestion(question, options) — given a multiple-choice quiz
 *      question, return the best answer with brief reasoning.
 *   3. decideNextAction(snapshot, goal) — for free-form custom tasks, look at
 *      the current page snapshot and decide the next primitive browser action.
 *   4. summarizeRun(actions, log) — produce a friendly end-of-run summary.
 */

import ZAI from "z-ai-web-dev-sdk";

let zaiPromise: Promise<ZAI> | null = null;
async function getZAI(): Promise<ZAI> {
  if (!zaiPromise) zaiPromise = ZAI.create();
  return zaiPromise;
}

export type PlanActionType =
  | "navigate"
  | "login"
  | "explore"
  | "play_quiz"
  | "watch_video"
  | "browse"
  | "custom";

export interface PlannedAction {
  type: PlanActionType;
  description: string;
  target?: string; // URL or quiz/course name
  detail?: string;
}

const SYSTEM_PROMPT_PLANNER = `You are a strict planner for an AI agent that automates the website https://www.itza.io.
ITZA is a learning platform with:
- Quizzes (e.g. Cricket Quiz Challenge, Football Quiz Challenge, Wild Wisdom Global Challenge, Ocean Odyssey quiz)
- Video courses (e.g. Ocean Odyssey, Egypt, Hip Hop Holiday, Indigo Journeys, Dolphins, Money Matters, Unknown Universe, Alien Hunting)
- A "My ITZA" dashboard at /my-itza
- A Store at /store
- A homepage at / that lists trending stories and learning journeys

Given a user's natural-language task, output an ordered JSON plan of high-level actions.
Each action MUST have a "type" (one of: navigate, login, explore, play_quiz, watch_video, browse, custom) and a short human-readable "description".
Use "target" for a specific URL or course/quiz name when relevant. Use "detail" for extra instructions.

Allowed types:
- "navigate"   : open a specific URL (target = absolute or relative URL)
- "login"      : sign in to ITZA using stored credentials
- "explore"    : visit the homepage and catalogue available quizzes/courses/videos
- "play_quiz"  : open a quiz and answer its questions (target = quiz name or URL)
- "watch_video": open a course and play its videos end-to-end (target = course name or URL)
- "browse"     : visit multiple pages of a kind (detail = e.g. "all trending stories")
- "custom"     : free-form LLM-driven browsing subtask (description = the sub-goal)

Respond with ONLY a JSON object of shape: { "actions": [ { "type": "...", "description": "...", "target": "...", "detail": "..." }, ... ] }
Do not include any prose, code fences, or commentary. Maximum 8 actions. Be practical: most tasks should be 2-5 actions.`;

export async function planTask(prompt: string): Promise<PlannedAction[]> {
  const zai = await getZAI();
  try {
    const resp = await zai.chat.completions.create({
      messages: [
        { role: "system", content: SYSTEM_PROMPT_PLANNER },
        {
          role: "user",
          content: `User task: """${prompt}"""\n\nProduce the JSON plan now.`,
        },
      ],
      temperature: 0.2,
    });
    const content: string =
      resp?.choices?.[0]?.message?.content ?? "";
    const actions = parsePlanJson(content);
    if (actions.length === 0) {
      // Fallback: treat the whole thing as one custom action
      return [
        {
          type: "custom",
          description: prompt,
          detail: "Free-form browsing task",
        },
      ];
    }
    return actions;
  } catch (err) {
    return [
      {
        type: "custom",
        description: prompt,
        detail: `LLM planning failed: ${(err as Error).message}`,
      },
    ];
  }
}

function parsePlanJson(content: string): PlannedAction[] {
  // Extract first {...} block
  let text = content.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) text = fence[1].trim();
  const firstBrace = text.indexOf("{");
  const lastBrace = text.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    text = text.slice(firstBrace, lastBrace + 1);
  }
  try {
    const obj = JSON.parse(text);
    if (!obj || !Array.isArray(obj.actions)) return [];
    return obj.actions
      .filter((a: any) => a && typeof a.type === "string")
      .slice(0, 8)
      .map((a: any) => ({
        type: String(a.type) as PlanActionType,
        description: String(a.description ?? a.type).slice(0, 240),
        target: a.target ? String(a.target).slice(0, 240) : undefined,
        detail: a.detail ? String(a.detail).slice(0, 400) : undefined,
      }));
  } catch {
    return [];
  }
}

const SYSTEM_PROMPT_QUIZ = `You are an expert general-knowledge assistant answering multiple-choice questions on the ITZA learning platform (topics include cricket, football, ocean life, ancient Egypt, hip hop history, indigo dye, dolphins, money skills, space, etc.).

For each question you will receive the question text and the list of options. Reply with ONLY a JSON object:
{ "answerIndex": <0-based index of the best option>, "reasoning": "<one short sentence>" }

Pick the single best answer. If you are unsure, pick the most plausible option. Never refuse. Never add prose outside the JSON.`;

export async function answerQuizQuestion(
  question: string,
  options: string[],
): Promise<{ answerIndex: number; reasoning: string }> {
  const zai = await getZAI();
  try {
    const resp = await zai.chat.completions.create({
      messages: [
        { role: "system", content: SYSTEM_PROMPT_QUIZ },
        {
          role: "user",
          content: JSON.stringify(
            { question, options },
            null,
            2,
          ),
        },
      ],
      temperature: 0.1,
    });
    const content: string = resp?.choices?.[0]?.message?.content ?? "";
    let text = content.trim();
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fence) text = fence[1].trim();
    const firstBrace = text.indexOf("{");
    const lastBrace = text.lastIndexOf("}");
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      text = text.slice(firstBrace, lastBrace + 1);
    }
    const obj = JSON.parse(text);
    const idx = Number(obj.answerIndex);
    if (
      Number.isInteger(idx) &&
      idx >= 0 &&
      idx < options.length
    ) {
      return {
        answerIndex: idx,
        reasoning: String(obj.reasoning ?? "").slice(0, 240),
      };
    }
  } catch {
    /* ignore */
  }
  // Fallback: pick option 0
  return { answerIndex: 0, reasoning: "Defaulted to first option (LLM parse failed)" };
}

const SYSTEM_PROMPT_DECIDER = `You are driving an automated browser session on https://www.itza.io to accomplish a goal.
You are given the goal and a compact snapshot of the current page (interactive elements with @refs).

Decide the SINGLE next primitive action to take. Reply with ONLY a JSON object:
{ "action": "<navigate|click|fill|scroll|done>", "ref": "@eN or null", "value": "URL or text or null", "reason": "<short>" }

Rules:
- "navigate": value must be an absolute or /relative URL
- "click":    ref must be a real @ref from the snapshot
- "fill":     ref + value (the text to type)
- "scroll":   value is "up" or "down"
- "done":     when the goal is fully achieved

Never invent refs. If no progress can be made, return "done" with a reason.`;

export interface PageSnapshotItem {
  ref: string;
  role?: string;
  name?: string;
  text?: string;
}

export async function decideNextAction(
  goal: string,
  snapshot: PageSnapshotItem[],
  recentActions: string[],
): Promise<{
  action: "navigate" | "click" | "fill" | "scroll" | "done";
  ref?: string | null;
  value?: string | null;
  reason?: string;
}> {
  const zai = await getZAI();
  try {
    const resp = await zai.chat.completions.create({
      messages: [
        { role: "system", content: SYSTEM_PROMPT_DECIDER },
        {
          role: "user",
          content: JSON.stringify(
            {
              goal,
              currentUrl: "(see snapshot)",
              recentActions: recentActions.slice(-10),
              snapshot: snapshot.slice(0, 80),
            },
            null,
            2,
          ),
        },
      ],
      temperature: 0.1,
    });
    const content: string = resp?.choices?.[0]?.message?.content ?? "";
    let text = content.trim();
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fence) text = fence[1].trim();
    const firstBrace = text.indexOf("{");
    const lastBrace = text.lastIndexOf("}");
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      text = text.slice(firstBrace, lastBrace + 1);
    }
    const obj = JSON.parse(text);
    return {
      action: String(obj.action) as any,
      ref: obj.ref ? String(obj.ref) : null,
      value: obj.value != null ? String(obj.value) : null,
      reason: obj.reason ? String(obj.reason).slice(0, 240) : "",
    };
  } catch {
    return { action: "done", reason: "LLM decider failed" };
  }
}

export async function summarizeRun(
  prompt: string,
  actions: { type: string; description: string; status: string; detail?: string }[],
  logTail: string[],
): Promise<string> {
  const zai = await getZAI();
  try {
    const resp = await zai.chat.completions.create({
      messages: [
        {
          role: "system",
          content:
            "You write a concise, HONEST 2-4 sentence summary of an agent run for the user. Be concrete about what was actually accomplished vs. what was skipped or failed. If zero quiz questions were answered or zero videos played, say so explicitly. No emojis, no headers, no marketing fluff, no false success claims.",
        },
        {
          role: "user",
          content: JSON.stringify(
            {
              userTask: prompt,
              actions: actions.map((a) => ({
                type: a.type,
                description: a.description,
                status: a.status,
                detail: a.detail,
              })),
              logTail,
            },
            null,
            2,
          ),
        },
      ],
      temperature: 0.3,
    });
    const content: string = resp?.choices?.[0]?.message?.content ?? "";
    return content.trim().slice(0, 600);
  } catch {
    return "Run finished.";
  }
}
