/**
 * Orchestrates a single agent run: plan → execute → summarize.
 *
 * Holds the "currently running" session ID so only one agent runs at a time
 * per server process (we have one shared Playwright page). Subsequent start
 * requests while a run is in progress are rejected with a friendly message.
 */

import { sessionStore } from "@/lib/agent/sessions";
import { planTask, summarizeRun, type PlannedAction } from "./llm-planner";
import {
  browseTrending,
  closeBrowser,
  customBrowsingLoop,
  explore,
  login,
  navigateTo,
  playQuiz,
  watchVideo,
} from "./itza-engine";

export interface StartArgs {
  taskKind: string; // "quiz" | "video" | "browse" | "custom" | "login" | "explore"
  prompt: string;
  credentials?: { email: string; password: string };
}

// We keep the "currently running" session ID on globalThis so it survives
// dev-mode hot reloads (a module-level `let` would be reset on recompile,
// causing the delete endpoint to think nothing is running).
const g = globalThis as unknown as {
  __agentCurrentRunId?: string | null;
  __browserMode?: "manual" | "agent";
};

function getCurrentRunId(): string | null {
  return g.__agentCurrentRunId ?? null;
}

// Exported for the delete endpoint to check if a session is currently running.
export { getCurrentRunId };

function setCurrentRunId(id: string | null): void {
  g.__agentCurrentRunId = id;
}

/**
 * Returns the current browser control mode:
 *  - "manual": user is driving the browser (agent must wait)
 *  - "agent": agent is driving the browser (manual clicks rejected)
 */
export function getBrowserMode(): "manual" | "agent" {
  return g.__browserMode ?? "manual";
}

export function setBrowserMode(mode: "manual" | "agent"): void {
  g.__browserMode = mode;
}

export async function startAgent(args: StartArgs): Promise<{ sessionId: string }> {
  const running = getCurrentRunId();
  if (running) {
    const existing = sessionStore.get(running);
    if (existing && (existing.status === "running" || existing.status === "planning" || existing.status === "queued")) {
      throw new Error(
        `Another run is already in progress (session ${running}). Wait for it to finish or stop it first.`,
      );
    }
  }

  const session = sessionStore.create({
    taskKind: args.taskKind,
    prompt: args.prompt,
  });
  setCurrentRunId(session.id);
  setBrowserMode("agent"); // Agent takes over the browser

  // Fire-and-forget the run loop
  void runAgentLoop(session.id, args).catch((err) => {
    sessionStore.log(
      session.id,
      "error",
      `Fatal orchestrator error: ${(err as Error).message}`,
    );
    sessionStore.update(session.id, {
      status: "failed",
      errorMessage: (err as Error).message,
      finishedAt: Date.now(),
    });
    if (getCurrentRunId() === session.id) setCurrentRunId(null);
    setBrowserMode("manual"); // Return control to user
  });

  return { sessionId: session.id };
}

export async function stopAgent(sessionId: string): Promise<void> {
  sessionStore.update(sessionId, { stopRequested: true });
  sessionStore.log(sessionId, "warn", "Stop requested by user.");
}

async function runAgentLoop(sessionId: string, args: StartArgs): Promise<void> {
  const session = sessionStore.get(sessionId);
  if (!session) return;
  sessionStore.update(sessionId, { status: "planning", startedAt: Date.now() });
  sessionStore.log(sessionId, "info", `Planning task: "${args.prompt}"`);

  let plan: PlannedAction[] = [];
  try {
    plan = await planTask(args.prompt);
  } catch (err) {
    sessionStore.log(
      sessionId,
      "error",
      `Planning failed: ${(err as Error).message}`,
    );
    sessionStore.update(sessionId, {
      status: "failed",
      errorMessage: (err as Error).message,
      finishedAt: Date.now(),
    });
    if (getCurrentRunId() === sessionId) {
      setCurrentRunId(null);
      setBrowserMode("manual");
    }
    return;
  }

  // Always start from a clean slate: a "navigate" to homepage if not present
  if (!plan.some((p) => p.type === "navigate" || p.type === "login")) {
    plan.unshift({
      type: "navigate",
      description: "Open ITZA homepage",
      target: "https://www.itza.io",
    });
  }

  // Materialize plan into session actions
  const actions = plan.map((p, i) => ({
    id: `a_${i}`,
    index: i,
    type: p.type as any,
    description: p.description,
    status: "pending" as const,
    detail: p.detail,
  }));
  sessionStore.update(sessionId, { plan: actions, status: "running" });
  sessionStore.log(
    sessionId,
    "info",
    `Plan with ${actions.length} step(s) ready.`,
  );

  // Execute each action in order
  for (let i = 0; i < actions.length; i++) {
    const s = sessionStore.get(sessionId);
    if (!s) break;
    if (s.stopRequested) {
      sessionStore.log(sessionId, "warn", "Run stopped before next action.");
      // Mark remaining as skipped
      for (let j = i; j < actions.length; j++) {
        actions[j].status = "skipped";
      }
      sessionStore.update(sessionId, { plan: actions });
      break;
    }
    const action = actions[i];
    try {
      switch (action.type) {
        case "navigate":
          await navigateTo(sessionId, i, action.target);
          break;
        case "login":
          if (args.credentials) {
            await login(sessionId, i, args.credentials.email, args.credentials.password);
          } else {
            sessionStore.log(
              sessionId,
              "warn",
              "Login step requested but no credentials supplied — skipping.",
            );
            action.status = "skipped";
          }
          break;
        case "explore":
          await explore(sessionId, i);
          break;
        case "play_quiz":
          await playQuiz(sessionId, i, action.target);
          break;
        case "watch_video":
          await watchVideo(sessionId, i, action.target);
          break;
        case "browse":
          await browseTrending(sessionId, i, 6);
          break;
        case "custom":
          await customBrowsingLoop(sessionId, i, action.description);
          break;
      }
    } catch (err) {
      sessionStore.log(
        sessionId,
        "error",
        `Action ${i + 1} (${action.type}) failed: ${(err as Error).message}`,
      );
      // Continue to next action rather than aborting the whole run
    }
    sessionStore.update(sessionId, { plan: actions });
  }

  // Summarize
  const finalSession = sessionStore.get(sessionId);
  if (finalSession && !finalSession.stopRequested) {
    const summary = await summarizeRun(
      args.prompt,
      finalSession.plan.map((a) => ({
        type: a.type,
        description: a.description,
        status: a.status,
        detail: a.detail,
      })),
      finalSession.log.slice(-30).map((l) => l.message),
    );
    sessionStore.log(sessionId, "success", `Summary: ${summary}`);
  }

  const finalStatus = sessionStore.get(sessionId)?.stopRequested
    ? "stopped"
    : "completed";
  sessionStore.update(sessionId, {
    status: finalStatus,
    finishedAt: Date.now(),
  });
  if (getCurrentRunId() === sessionId) {
    setCurrentRunId(null);
    setBrowserMode("manual"); // Return control to user
  }
}

// Keep browser alive between runs; expose for explicit shutdown
export async function shutdownBrowser(): Promise<void> {
  await closeBrowser();
}
