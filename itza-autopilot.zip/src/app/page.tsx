"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Brain,
  Play,
  Square,
  RefreshCw,
  Globe,
  Trophy,
  Video,
  Compass,
  LogIn,
  Sparkles,
  Clock,
  Activity,
  Camera,
  ChevronRight,
  Loader2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Info,
  Eye,
  EyeOff,
  Settings,
  History,
  Zap,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";

type Status = "queued" | "planning" | "running" | "completed" | "failed" | "stopped";
type ActionStatus = "pending" | "running" | "done" | "skipped" | "error";

interface PlanAction {
  id: string;
  index: number;
  type: string;
  description: string;
  status: ActionStatus;
  startedAt?: number;
  finishedAt?: number;
  detail?: string;
}

interface LogEntry {
  id: string;
  ts: number;
  level: "info" | "success" | "warn" | "error" | "debug";
  message: string;
}

interface ScreenshotRecord {
  id: string;
  ts: number;
  caption: string;
  actionIndex?: number;
  path: string;
}

interface SessionStats {
  actionsCompleted: number;
  quizzesAnswered: number;
  videosWatched: number;
  pagesVisited: number;
}

interface SessionView {
  id: string;
  taskKind: string;
  prompt: string;
  status: Status;
  createdAt: number;
  updatedAt: number;
  startedAt?: number;
  finishedAt?: number;
  plan: PlanAction[];
  log: LogEntry[];
  screenshots: ScreenshotRecord[];
  currentPageUrl?: string;
  currentPageTitle?: string;
  errorMessage?: string;
  stats: SessionStats;
  stopRequested: boolean;
}

interface HistoryItem {
  id: string;
  taskKind: string;
  prompt: string;
  status: Status;
  createdAt: number;
  updatedAt: number;
  startedAt?: number;
  finishedAt?: number;
  stats: SessionStats;
  actionCount: number;
  logTail: string[];
}

const TASK_TEMPLATES: Array<{
  kind: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  prompt: string;
  color: string;
}> = [
  {
    kind: "quiz",
    title: "Play a Quiz",
    icon: Trophy,
    description: "Sign in, open any ITZA quiz, and let the LLM answer every question.",
    prompt:
      "Sign in to ITZA, then play the Cricket Quiz Challenge. Answer every question using the LLM and finish the quiz.",
    color: "bg-amber-500/10 text-amber-600 border-amber-500/30",
  },
  {
    kind: "video",
    title: "Watch a Course",
    icon: Video,
    description: "Open a video course (Ocean Odyssey, Egypt, etc.) and play every video through.",
    prompt:
      "Open the Ocean Odyssey course on ITZA and watch all its videos from start to finish, advancing through each section.",
    color: "bg-rose-500/10 text-rose-600 border-rose-500/30",
  },
  {
    kind: "browse",
    title: "Browse Trending",
    icon: Compass,
    description: "Visit the homepage and walk through every trending story and learning journey.",
    prompt:
      "Browse the trending stories on the ITZA homepage — visit each one and scroll through it to read the content.",
    color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
  },
  {
    kind: "explore",
    title: "Explore Everything",
    icon: Globe,
    description: "Catalogue every quiz, course and video currently available on ITZA.",
    prompt:
      "Explore the ITZA homepage and catalogue all available quizzes, courses and videos, noting their URLs.",
    color: "bg-cyan-500/10 text-cyan-600 border-cyan-500/30",
  },
  {
    kind: "login",
    title: "Sign In Only",
    icon: LogIn,
    description: "Just sign in to ITZA with your credentials and land on your dashboard.",
    prompt:
      "Sign in to ITZA with the provided credentials and land on the My ITZA dashboard.",
    color: "bg-violet-500/10 text-violet-600 border-violet-500/30",
  },
  {
    kind: "custom",
    title: "Custom Task",
    icon: Sparkles,
    description: "Describe anything you want the agent to do on ITZA — it will figure out the steps.",
    prompt:
      "Explore the Egypt course, watch its first video, then go to the Money Matters course and read its description.",
    color: "bg-fuchsia-500/10 text-fuchsia-600 border-fuchsia-500/30",
  },
];

const STATUS_META: Record<Status, { label: string; color: string; icon: React.ComponentType<{ className?: string }>; }> = {
  queued: { label: "Queued", color: "bg-slate-500/10 text-slate-600 border-slate-500/30", icon: Clock },
  planning: { label: "Planning", color: "bg-blue-500/10 text-blue-600 border-blue-500/30", icon: Brain },
  running: { label: "Running", color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30", icon: Activity },
  completed: { label: "Completed", color: "bg-emerald-500/10 text-emerald-700 border-emerald-500/30", icon: CheckCircle2 },
  failed: { label: "Failed", color: "bg-rose-500/10 text-rose-600 border-rose-500/30", icon: XCircle },
  stopped: { label: "Stopped", color: "bg-amber-500/10 text-amber-600 border-amber-500/30", icon: Square },
};

const ACTION_STATUS_META: Record<ActionStatus, { color: string; icon: React.ComponentType<{ className?: string }>; }> = {
  pending: { color: "text-slate-400", icon: Clock },
  running: { color: "text-emerald-600", icon: Loader2 },
  done: { color: "text-emerald-600", icon: CheckCircle2 },
  skipped: { color: "text-amber-600", icon: AlertCircle },
  error: { color: "text-rose-600", icon: XCircle },
};

const ACTION_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  navigate: Globe,
  login: LogIn,
  explore: Compass,
  play_quiz: Trophy,
  watch_video: Video,
  browse: Compass,
  custom: Sparkles,
  snapshot: Camera,
  click: Zap,
  fill: Zap,
  wait: Clock,
  answer_quiz: Brain,
};

function timeAgo(ts: number): string {
  const diff = Math.max(0, Date.now() - ts);
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return new Date(ts).toLocaleString();
}

function durationLabel(ms?: number): string {
  if (!ms) return "—";
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  return `${m}m ${s % 60}s`;
}

export default function Home() {
  const [prompt, setPrompt] = useState<string>(TASK_TEMPLATES[0].prompt);
  const [taskKind, setTaskKind] = useState<string>(TASK_TEMPLATES[0].kind);
  // Restore last sessionId from localStorage so a page refresh doesn't lose state
  const [sessionId, setSessionId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    try {
      return window.localStorage.getItem("itza_autopilot_sid") || null;
    } catch {
      return null;
    }
  });
  const [session, setSession] = useState<SessionView | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isStarting, setIsStarting] = useState(false);
  const [credentials, setCredentials] = useState<{ email: string; password: string }>({ email: "", password: "" });
  const [credsOpen, setCredsOpen] = useState(false);
  const [includeCreds, setIncludeCreds] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Persist sessionId to localStorage whenever it changes
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      if (sessionId) {
        window.localStorage.setItem("itza_autopilot_sid", sessionId);
      } else {
        window.localStorage.removeItem("itza_autopilot_sid");
      }
    } catch {
      /* ignore */
    }
  }, [sessionId]);

  // Load history on mount
  const refreshHistory = useCallback(async () => {
    try {
      const r = await fetch("/api/agent/sessions", { cache: "no-store" });
      if (r.ok) {
        const j = await r.json();
        setHistory(j.sessions || []);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    refreshHistory();
  }, [refreshHistory]);

  // Poll for session status while running
  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    let consecutiveErrors = 0;

    const poll = async () => {
      try {
        const r = await fetch(
          `/api/agent/status?sessionId=${encodeURIComponent(sessionId)}`,
          { cache: "no-store" },
        );
        if (r.status === 404) {
          // Session no longer exists on server (e.g. server restarted or was
          // deleted). Stop polling and clear local state.
          if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
          }
          setSession(null);
          setSessionId(null);
          toast.info("Session no longer exists on server — cleared.");
          refreshHistory();
          return;
        }
        if (!r.ok) {
          consecutiveErrors += 1;
          if (consecutiveErrors >= 5) {
            if (pollRef.current) {
              clearInterval(pollRef.current);
              pollRef.current = null;
            }
            toast.error("Lost contact with agent — stopping polling.");
          }
          return;
        }
        consecutiveErrors = 0;
        const j = await r.json();
        if (cancelled) return;
        setSession(j.session);
        if (
          j.session.status === "completed" ||
          j.session.status === "failed" ||
          j.session.status === "stopped"
        ) {
          if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
          }
          refreshHistory();
          if (j.session.status === "completed") {
            toast.success("Agent run completed");
          } else if (j.session.status === "failed") {
            toast.error("Agent run failed");
          } else {
            toast.info("Agent run stopped");
          }
        }
      } catch {
        consecutiveErrors += 1;
        if (consecutiveErrors >= 5) {
          if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
          }
        }
      }
    };

    void poll();
    pollRef.current = setInterval(poll, 1000);

    return () => {
      cancelled = true;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [sessionId, refreshHistory]);

  const isRunning = useMemo(
    () =>
      session?.status === "queued" ||
      session?.status === "planning" ||
      session?.status === "running",
    [session?.status],
  );

  const progress = useMemo(() => {
    if (!session || session.plan.length === 0) return 0;
    const done = session.plan.filter(
      (a) => a.status === "done" || a.status === "skipped" || a.status === "error",
    ).length;
    return Math.round((done / session.plan.length) * 100);
  }, [session]);

  const handleStart = useCallback(async () => {
    setIsStarting(true);
    try {
      const body: Record<string, unknown> = {
        taskKind,
        prompt,
      };
      if (includeCreds && credentials.email) {
        body.credentials = credentials;
      }
      const r = await fetch("/api/agent/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        let errorMsg = `HTTP ${r.status}`;
        const contentType = r.headers.get("content-type") || "";
        if (contentType.includes("application/json")) {
          try {
            const j = await r.json();
            errorMsg = j.error || errorMsg;
          } catch {
            errorMsg = r.statusText || errorMsg;
          }
        } else {
          // Server returned non-JSON (e.g. HTML error page) — use status text
          errorMsg = r.statusText || `Server returned ${r.status}`;
        }
        // User-friendly messages for common errors
        if (r.status === 409) {
          errorMsg = "Another agent run is already in progress. Wait for it to finish, or stop it first using the red Stop button.";
        } else if (r.status === 400) {
          errorMsg = "Invalid request: " + errorMsg;
        } else if (r.status === 413) {
          errorMsg = "Prompt is too long. Keep it under 2000 characters.";
        } else if (r.status >= 500) {
          errorMsg = "Server error: " + errorMsg + ". The browser may still be starting up — wait 5 seconds and try again.";
        }
        throw new Error(errorMsg);
      }
      const j = await r.json();
      setSessionId(j.sessionId);
      setSession(null);
      toast.success("Agent started — scroll down to see live progress");
      // Scroll the live run panel into view so the user sees progress
      setTimeout(() => {
        const liveRun = document.getElementById("live-run-panel");
        if (liveRun) {
          liveRun.scrollIntoView({ behavior: "smooth", block: "start" });
        } else {
          // Fallback: scroll down by viewport height
          window.scrollBy({ top: window.innerHeight * 0.8, behavior: "smooth" });
        }
      }, 300);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setIsStarting(false);
    }
  }, [taskKind, prompt, includeCreds, credentials]);

  const handleStop = useCallback(async () => {
    if (!sessionId) return;
    try {
      await fetch("/api/agent/stop", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });
      toast.info("Stop requested");
    } catch (err) {
      toast.error((err as Error).message);
    }
  }, [sessionId]);

  const handleTemplateClick = (t: (typeof TASK_TEMPLATES)[number]) => {
    setTaskKind(t.kind);
    setPrompt(t.prompt);
  };

  const handleLoadHistory = useCallback(async (id: string) => {
    try {
      const r = await fetch(`/api/agent/status?sessionId=${encodeURIComponent(id)}`, { cache: "no-store" });
      if (r.status === 404) {
        toast.info("Session no longer exists — refreshing history.");
        refreshHistory();
        return;
      }
      if (!r.ok) return;
      const j = await r.json();
      setSession(j.session);
      setSessionId(id);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      toast.error((err as Error).message);
    }
  }, [refreshHistory]);

  const handleDeleteHistory = useCallback(async (id: string) => {
    try {
      const r = await fetch("/api/agent/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: id }),
      });
      if (!r.ok) {
        const j = await r.json().catch(() => ({ error: "Delete failed" }));
        throw new Error(j.error || `HTTP ${r.status}`);
      }
      toast.success("Session deleted");
      if (sessionId === id) {
        setSession(null);
        setSessionId(null);
      }
      refreshHistory();
    } catch (err) {
      toast.error((err as Error).message);
    }
  }, [sessionId, refreshHistory]);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 via-white to-slate-50 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200/60 dark:border-slate-800/60 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-500 via-cyan-500 to-blue-500 grid place-items-center shadow-sm">
              <Brain className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-semibold tracking-tight">
                ITZA AutoPilot
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                AI agent for <span className="font-medium text-slate-700 dark:text-slate-300">itza.io</span> — quizzes, videos, browsing
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://www.itza.io"
              target="_blank"
              rel="noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              <Globe className="h-3.5 w-3.5" /> itza.io
            </a>
            <Button variant="outline" size="sm" onClick={() => setCredsOpen(true)}>
              <ShieldCheck className="h-3.5 w-3.5 mr-1.5" /> Credentials
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 lg:py-10">
        {/* Hero */}
        <section className="mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Sign in to ITZA on the left, then let the AI agent take over.
          </h2>
          <p className="mt-2 text-slate-600 dark:text-slate-400 max-w-2xl">
            The browser panel on the left is a real, interactive ITZA website. Browse it yourself — sign in, sign up, play quizzes. When you give the agent a task, it drives the <strong>same browser session</strong>, so your login carries over.
          </p>
        </section>

        {/* Task templates */}
        <section className="mb-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {TASK_TEMPLATES.map((t) => {
              const Icon = t.icon;
              const active = taskKind === t.kind;
              return (
                <button
                  key={t.kind}
                  type="button"
                  onClick={() => handleTemplateClick(t)}
                  className={`group relative text-left rounded-xl border p-3 transition-all hover:shadow-md hover:-translate-y-0.5 ${
                    active
                      ? "border-slate-900 dark:border-white shadow-sm ring-1 ring-slate-900/10 dark:ring-white/10"
                      : "border-slate-200 dark:border-slate-800"
                  } bg-white dark:bg-slate-900`}
                >
                  <div className={`inline-flex h-8 w-8 items-center justify-center rounded-lg border ${t.color}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="mt-2 text-sm font-semibold leading-tight">
                    {t.title}
                  </div>
                  <div className="mt-1 text-[11px] leading-snug text-slate-500 dark:text-slate-400">
                    {t.description}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Composer */}
        <section className="mb-8">
          <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-fuchsia-500" /> Task prompt
                  </CardTitle>
                  <CardDescription className="mt-1">
                    Describe what you want the agent to accomplish on itza.io.
                  </CardDescription>
                </div>
                <Badge variant="outline" className="shrink-0">
                  Mode: {taskKind}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prompt" className="text-xs uppercase tracking-wide text-slate-500">
                  Your instruction
                </Label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  placeholder="e.g. Sign in, then play the Wild Wisdom Global Challenge quiz and answer every question."
                  className="resize-y font-mono text-sm"
                />
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
                <label className="inline-flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeCreds}
                    onChange={(e) => setIncludeCreds(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300"
                  />
                  Attach ITZA credentials
                  {includeCreds && credentials.email ? (
                    <Badge variant="secondary" className="ml-1 text-[10px]">
                      {credentials.email}
                    </Badge>
                  ) : null}
                </label>
                {(taskKind === "quiz" || taskKind === "login") && !includeCreds ? (
                  <span className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400">
                    <AlertCircle className="h-3.5 w-3.5" />
                    ITZA quizzes require sign-in. Add credentials to actually play.
                  </span>
                ) : null}
                <div className="flex items-center gap-2">
                  {isRunning ? (
                    <Button variant="destructive" onClick={handleStop} className="min-h-[44px]">
                      <Square className="h-4 w-4 mr-2" /> Stop run
                    </Button>
                  ) : (
                    <Button
                      onClick={handleStart}
                      disabled={isStarting || !prompt.trim()}
                      className="min-h-[44px]"
                      aria-label="Run agent"
                    >
                      {isStarting ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Play className="h-4 w-4 mr-2" />
                      )}
                      {isStarting ? "Starting…" : "Run agent"}
                    </Button>
                  )}
                  {isStarting && (
                    <span className="text-xs text-slate-500 animate-pulse">
                      Starting…
                    </span>
                  )}
                  {sessionId && !isStarting && (
                    <span className="text-xs text-emerald-600 font-medium">
                      ● Run active
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Side-by-side: Interactive Browser (left) + Task/Agent Panel (right) */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* LEFT: Interactive ITZA Browser — user can browse & sign in manually */}
          <div className="lg:sticky lg:top-20 lg:self-start lg:h-[calc(100vh-6rem)]">
            <InteractiveBrowserPanel
              isAgentRunning={isRunning}
              onAgentRunningChange={(v) => {
                // When agent mode ends, the browser panel auto-reverts to manual
              }}
            />
          </div>

          {/* RIGHT: Task prompt + agent activity */}
          <div className="space-y-6" id="live-run-panel">
            <ItzaSignInCard
              credentials={credentials}
              onChange={setCredentials}
              includeCreds={includeCreds}
              onToggleCreds={setIncludeCreds}
            />
            {!session ? (
              <Card className="border-dashed border-slate-300 dark:border-slate-700">
                <CardContent className="py-10 flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-slate-100 dark:bg-slate-800 grid place-items-center mb-4">
                    {isStarting ? (
                      <Loader2 className="h-6 w-6 text-emerald-500 animate-spin" />
                    ) : (
                      <Brain className="h-6 w-6 text-slate-400" />
                    )}
                  </div>
                  <h3 className="text-base font-semibold text-slate-700 dark:text-slate-300">
                    {isStarting ? "Starting agent…" : "Agent ready"}
                  </h3>
                  <p className="mt-1 text-sm text-slate-500 max-w-sm">
                    {isStarting
                      ? "Waiting for the server to acknowledge the run…"
                      : "Write a task above and click Run agent. The agent will drive the browser on the left — using your manual login if you signed in."}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <LiveRunView
                session={session}
                progress={progress}
                onStop={handleStop}
                isRunning={isRunning}
              />
            )}
            <StatsRail session={session} />
            <HistoryRail
              history={history}
              onLoad={handleLoadHistory}
              onDelete={handleDeleteHistory}
              onRefresh={refreshHistory}
              currentSessionId={sessionId}
            />
          </div>
        </section>

        <Separator className="my-10" />

        <HowItWorks />
      </main>

      <footer className="border-t border-slate-200/60 dark:border-slate-800/60 py-6 text-center text-xs text-slate-500">
        ITZA AutoPilot · runs a real headless Chromium via Playwright · LLM planning via z-ai-web-dev-sdk · credentials are kept in memory only
      </footer>

      <CredentialsDialog
        open={credsOpen}
        onOpenChange={setCredsOpen}
        credentials={credentials}
        onChange={setCredentials}
      />
    </div>
  );
}

/* ─────────────────── Live Run ─────────────────── */

function LiveRunView({
  session,
  progress,
  onStop,
  isRunning,
}: {
  session: SessionView;
  progress: number;
  onStop: () => void;
  isRunning: boolean;
}) {
  const statusMeta = STATUS_META[session.status];
  const StatusIcon = statusMeta.icon;
  const [activeTab, setActiveTab] = useState<string>("browser");
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeTab === "log") {
      logEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [session.log.length, activeTab]);

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <CardTitle className="text-base flex items-center gap-2">
              <Badge className={`border ${statusMeta.color} rounded-full`}>
                <StatusIcon className={`h-3 w-3 mr-1 ${session.status === "running" || session.status === "planning" ? "animate-spin" : ""}`} />
                {statusMeta.label}
              </Badge>
              <span className="truncate">{session.prompt}</span>
            </CardTitle>
            <CardDescription className="mt-1 text-xs">
              Session <code className="text-[10px]">{session.id}</code> · started {session.startedAt ? timeAgo(session.startedAt) : "—"}
              {session.currentPageTitle ? (
                <> · on <span className="font-medium text-slate-700 dark:text-slate-300">{session.currentPageTitle}</span></>
              ) : null}
            </CardDescription>
          </div>
          {isRunning ? (
            <Button size="sm" variant="destructive" onClick={onStop}>
              <Square className="h-3.5 w-3.5 mr-1.5" /> Stop
            </Button>
          ) : null}
        </div>
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Progress</span>
            <span className="font-mono">{progress}%</span>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browser"><Globe className="h-3.5 w-3.5 mr-1.5" />Browser</TabsTrigger>
            <TabsTrigger value="plan"><Brain className="h-3.5 w-3.5 mr-1.5" />Plan</TabsTrigger>
            <TabsTrigger value="log"><Activity className="h-3.5 w-3.5 mr-1.5" />Log</TabsTrigger>
            <TabsTrigger value="screenshots"><Camera className="h-3.5 w-3.5 mr-1.5" />Shots</TabsTrigger>
          </TabsList>

          <TabsContent value="browser" className="mt-4">
            <LiveBrowserView session={session} isRunning={isRunning} />
          </TabsContent>

          <TabsContent value="plan" className="mt-4">
            <ol className="space-y-2">
              {session.plan.length === 0 ? (
                <li className="text-sm text-slate-500 italic">
                  {session.status === "planning"
                    ? "LLM is composing a plan…"
                    : "Plan will appear here once the LLM has decomposed your task."}
                </li>
              ) : (
                session.plan.map((a) => {
                  const meta = ACTION_STATUS_META[a.status];
                  const ActionIcon = ACTION_ICON[a.type] || Zap;
                  const StatusIco = meta.icon;
                  return (
                    <li
                      key={a.id}
                      className={`flex items-start gap-3 rounded-lg border p-3 ${
                        a.status === "running"
                          ? "border-emerald-300 dark:border-emerald-700 bg-emerald-50/40 dark:bg-emerald-950/20"
                          : "border-slate-200 dark:border-slate-800"
                      }`}
                    >
                      <div className="mt-0.5 h-7 w-7 rounded-md bg-slate-100 dark:bg-slate-800 grid place-items-center">
                        <ActionIcon className="h-3.5 w-3.5 text-slate-600 dark:text-slate-300" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-slate-400">#{a.index + 1}</span>
                          <span className="text-sm font-medium truncate">{a.description}</span>
                        </div>
                        <div className="mt-0.5 flex items-center gap-2 text-[11px] text-slate-500">
                          <span className={`inline-flex items-center gap-1 ${meta.color}`}>
                            <StatusIco className={`h-3 w-3 ${a.status === "running" ? "animate-spin" : ""}`} />
                            {a.status}
                          </span>
                          {a.startedAt && a.finishedAt ? (
                            <span>· {durationLabel(a.finishedAt - a.startedAt)}</span>
                          ) : null}
                          {a.detail ? (
                            <span className="truncate">· {a.detail}</span>
                          ) : null}
                        </div>
                      </div>
                    </li>
                  );
                })
              )}
            </ol>
          </TabsContent>

          <TabsContent value="log" className="mt-4">
            <ScrollArea className="h-[420px] rounded-lg border border-slate-200 dark:border-slate-800 p-3 bg-slate-50/50 dark:bg-slate-900/50">
              <div className="space-y-1 font-mono text-xs">
                {session.log.length === 0 ? (
                  <div className="text-slate-500 italic">No log entries yet.</div>
                ) : (
                  session.log.map((l) => {
                    const color =
                      l.level === "error"
                        ? "text-rose-600"
                        : l.level === "warn"
                          ? "text-amber-600"
                          : l.level === "success"
                            ? "text-emerald-600"
                            : l.level === "debug"
                              ? "text-slate-400"
                              : "text-slate-700 dark:text-slate-300";
                    return (
                      <div key={l.id} className="flex gap-2">
                        <span className="text-slate-400 shrink-0">
                          {new Date(l.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                        </span>
                        <span className={color}>{l.message}</span>
                      </div>
                    );
                  })
                )}
                <div ref={logEndRef} />
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="screenshots" className="mt-4">
            {session.screenshots.length === 0 ? (
              <div className="text-sm text-slate-500 italic">No screenshots captured yet.</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {session.screenshots
                  .slice()
                  .reverse()
                  .map((sc) => (
                    <a
                      key={sc.id}
                      href={sc.path}
                      target="_blank"
                      rel="noreferrer"
                      className="group block rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden hover:shadow-md transition-shadow"
                    >
                      <div className="aspect-video bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <img
                          src={sc.path}
                          alt={sc.caption}
                          className="h-full w-full object-cover object-top group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <div className="p-2">
                        <div className="text-xs font-medium truncate">{sc.caption}</div>
                        <div className="text-[10px] text-slate-500">{timeAgo(sc.ts)}</div>
                      </div>
                    </a>
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

/* ─────────────────── Interactive Browser Panel ─────────────────── */
/* This is the user-facing browser window. It shows a live screenshot of the
   Playwright browser and forwards clicks/typing to it. When the agent is
   running, the panel becomes read-only (take-turns mode). */

function InteractiveBrowserPanel({
  isAgentRunning,
  onAgentRunningChange,
}: {
  isAgentRunning: boolean;
  onAgentRunningChange: (v: boolean) => void;
}) {
  const [screenshotUrl, setScreenshotUrl] = useState<string>("");
  const [pageUrl, setPageUrl] = useState<string>("");
  const [pageTitle, setPageTitle] = useState<string>("");
  const [mode, setMode] = useState<"manual" | "agent">("manual");
  const [urlInput, setUrlInput] = useState<string>("https://www.itza.io");
  const [typingText, setTypingText] = useState<string>("");
  const [isBusy, setIsBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastClick, setLastClick] = useState<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Fetch a fresh screenshot + page state
  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/api/browser/state", { cache: "no-store" });
      if (r.ok) {
        const j = await r.json();
        setMode(j.mode);
        setPageUrl(j.pageUrl || "");
        setPageTitle(j.pageTitle || "");
        if (j.mode === "manual") {
          onAgentRunningChange(false);
        } else if (j.mode === "agent") {
          onAgentRunningChange(true);
        }
      }
    } catch {
      /* ignore */
    }
    // Cache-bust the screenshot
    setScreenshotUrl(`/api/browser/screenshot?t=${Date.now()}`);
  }, [onAgentRunningChange]);

  // Initial load + periodic refresh
  useEffect(() => {
    // Trigger browser initialization in the background immediately on mount
    fetch("/api/browser/init", { method: "POST" }).catch(() => {
      /* ignore */
    });
    void refresh();
    // On mobile, use a longer interval (2s) to reduce network load.
    // On desktop, use 800ms (manual) / 1.2s (agent).
    const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
    const interval = isMobile
      ? (mode === "agent" ? 2000 : 1500)
      : (mode === "agent" ? 1200 : 800);
    refreshTimerRef.current = setInterval(refresh, interval);
    return () => {
      if (refreshTimerRef.current) clearInterval(refreshTimerRef.current);
    };
  }, [refresh, mode]);

  // Handle click on the screenshot — forward to Playwright
  const handleClick = useCallback(
    async (e: React.MouseEvent<HTMLImageElement>) => {
      if (mode === "agent") {
        setError("Agent is controlling the browser. Wait for it to finish.");
        return;
      }
      const img = e.currentTarget;
      const rect = img.getBoundingClientRect();
      // The screenshot is 1366x850. Scale click coords back to that resolution.
      const scaleX = 1366 / rect.width;
      const scaleY = 850 / rect.height;
      const x = Math.round((e.clientX - rect.left) * scaleX);
      const y = Math.round((e.clientY - rect.top) * scaleY);
      setLastClick({ x, y });
      setIsBusy(true);
      setError(null);
      try {
        const r = await fetch("/api/browser/click", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ x, y }),
        });
        const contentType = r.headers.get("content-type") || "";
        if (contentType.includes("application/json")) {
          const j = await r.json();
          if (!r.ok || !j.ok) {
            // 503 = browser still launching — show friendly message, not an error
            if (r.status === 503) {
              setError("⏳ " + (j.error || "Browser is still loading. Wait a few seconds and try again."));
            } else {
              setError(j.error || `Click failed (HTTP ${r.status})`);
            }
          }
        } else {
          // Non-JSON response (server error page) — read as text
          const text = await r.text().catch(() => "");
          setError(`Server returned ${r.status}: ${text.slice(0, 80) || r.statusText}`);
        }
        // Refresh screenshot immediately after click
        setTimeout(() => void refresh(), 400);
      } catch (err) {
        // Network error (Failed to fetch) — likely the server is busy/restarting
        setError("Connection failed. The server may be busy loading the browser. Please wait and try again.");
      } finally {
        setIsBusy(false);
      }
    },
    [mode, refresh],
  );

  // Navigate to a URL
  const handleNavigate = useCallback(
    async (url?: string) => {
      const targetUrl = url ?? urlInput;
      if (mode === "agent") {
        setError("Agent is controlling the browser.");
        return;
      }
      setIsBusy(true);
      setError(null);
      try {
        const r = await fetch("/api/browser/navigate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: targetUrl }),
        });
        const contentType = r.headers.get("content-type") || "";
        if (contentType.includes("application/json")) {
          const j = await r.json();
          if (!r.ok || !j.ok) {
            setError(j.error || "Navigation failed");
          } else {
            setPageUrl(j.url || targetUrl);
            setPageTitle(j.title || "");
          }
        } else {
          setError(`Server returned ${r.status}: ${r.statusText}`);
        }
        setTimeout(() => void refresh(), 500);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setIsBusy(false);
      }
    },
    [urlInput, mode, refresh],
  );

  // Type text into focused element
  const handleType = useCallback(async () => {
    if (!typingText || mode === "agent") return;
    setIsBusy(true);
    setError(null);
    try {
      const r = await fetch("/api/browser/type", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: typingText }),
      });
      const j = await r.json();
      if (!r.ok || !j.ok) setError(j.error || "Type failed");
      setTypingText("");
      setTimeout(() => void refresh(), 400);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsBusy(false);
    }
  }, [typingText, mode, refresh]);

  // Press a key
  const handleKey = useCallback(
    async (key: string) => {
      if (mode === "agent") return;
      setIsBusy(true);
      try {
        await fetch("/api/browser/key", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key }),
        });
        setTimeout(() => void refresh(), 400);
      } finally {
        setIsBusy(false);
      }
    },
    [mode, refresh],
  );

  // Scroll / back / forward / reload
  const handleAction = useCallback(
    async (action: "scroll-up" | "scroll-down" | "back" | "forward" | "reload") => {
      if (mode === "agent") return;
      setIsBusy(true);
      setError(null);
      try {
        const endpoint =
          action === "scroll-up" || action === "scroll-down"
            ? "/api/browser/scroll"
            : action === "back"
              ? "/api/browser/back"
              : action === "forward"
                ? "/api/browser/forward"
                : "/api/browser/reload";
        const body =
          action === "scroll-up" || action === "scroll-down"
            ? { direction: action === "scroll-up" ? "up" : "down" }
            : {};
        await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        setTimeout(() => void refresh(), 500);
      } finally {
        setIsBusy(false);
      }
    },
    [mode, refresh],
  );

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-sm flex flex-col h-full">
      <CardHeader className="pb-2 flex-shrink-0">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <div className="h-7 w-7 rounded-md bg-gradient-to-br from-emerald-500/15 to-cyan-500/15 grid place-items-center">
              <Globe className="h-4 w-4 text-emerald-600" />
            </div>
            ITZA Browser
          </CardTitle>
          <div className="flex items-center gap-1.5">
            {mode === "agent" ? (
              <Badge className="bg-violet-500/10 text-violet-600 border-violet-500/30 text-[10px] animate-pulse">
                <Brain className="h-2.5 w-2.5 mr-1" /> AGENT DRIVING
              </Badge>
            ) : (
              <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[10px]">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 mr-1 inline-block" />
                MANUAL
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-2 min-h-0">
        {/* URL bar */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Button
            variant="outline"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => handleAction("back")}
            disabled={mode === "agent" || isBusy}
            title="Back"
          >
            <ChevronRight className="h-3.5 w-3.5 rotate-180" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => handleAction("forward")}
            disabled={mode === "agent" || isBusy}
            title="Forward"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => handleAction("reload")}
            disabled={mode === "agent" || isBusy}
            title="Reload"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
          <form
            className="flex-1 min-w-0 flex items-center gap-1"
            onSubmit={(e) => {
              e.preventDefault();
              void handleNavigate();
            }}
          >
            <Input
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="itza.io/..."
              className="h-8 text-xs font-mono"
              disabled={mode === "agent"}
            />
            <Button type="submit" size="sm" className="h-8" disabled={mode === "agent" || isBusy}>
              Go
            </Button>
          </form>
        </div>

        {/* Quick nav buttons */}
        <div className="flex gap-1.5 flex-shrink-0 flex-wrap">
          {[
            { label: "Home", url: "https://www.itza.io" },
            { label: "Explore", url: "https://www.itza.io/explore" },
            { label: "My ITZA", url: "https://www.itza.io/my-itza" },
            { label: "Store", url: "https://www.itza.io/store" },
          ].map((link) => (
            <Button
              key={link.label}
              variant="secondary"
              size="sm"
              className="h-7 text-[11px]"
              onClick={() => {
                setUrlInput(link.url);
                void handleNavigate(link.url);
              }}
              disabled={mode === "agent" || isBusy}
            >
              {link.label}
            </Button>
          ))}
          <div className="text-[10px] text-slate-500 self-center ml-1">
            Tip: Click <strong>Sign In</strong> / <strong>Sign Up</strong> on the ITZA page above to use ITZA's official login.
          </div>
        </div>

        {/* Screenshot / interactive area */}
        <div
          ref={containerRef}
          className="relative flex-1 min-h-[300px] rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-100 dark:bg-slate-900"
        >
          {screenshotUrl ? (
            <img
              src={screenshotUrl}
              alt="ITZA browser"
              onClick={handleClick}
              className={`absolute inset-0 w-full h-full object-contain object-top ${
                mode === "manual" ? "cursor-pointer" : "cursor-not-allowed"
              }`}
              onError={() => {
                // Retry after a longer delay if the screenshot fails to load.
                // Use 3s to avoid hammering the server while itza.io loads
                // (which can take 20-30 seconds on first load).
                setTimeout(() => setScreenshotUrl(`/api/browser/screenshot?t=${Date.now()}`), 3000);
              }}
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
              <Loader2 className="h-8 w-8 animate-spin mb-2" />
              <p className="text-sm">Launching browser…</p>
              <p className="text-xs mt-1 text-slate-400">Loading itza.io (this can take 15-20 seconds)</p>
            </div>
          )}

          {/* Click marker */}
          {lastClick && (
            <div
              className="absolute pointer-events-none"
              style={{
                left: `${(lastClick.x / 1366) * 100}%`,
                top: `${(lastClick.y / 850) * 100}%`,
                transform: "translate(-50%, -50%)",
              }}
            >
              <div className="h-4 w-4 rounded-full border-2 border-emerald-500 animate-ping" />
            </div>
          )}

          {/* Busy overlay */}
          {isBusy && (
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" /> Working…
            </div>
          )}

          {/* Page title overlay */}
          {pageTitle && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2 pointer-events-none">
              <div className="text-xs text-white font-medium truncate">{pageTitle}</div>
              <div className="text-[10px] text-white/60 truncate font-mono">{pageUrl}</div>
            </div>
          )}

          {/* Agent-mode overlay — clicks disabled */}
          {mode === "agent" && (
            <div className="absolute inset-0 bg-violet-500/5 pointer-events-none flex items-start justify-center pt-4">
              <div className="bg-violet-600 text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg">
                <Brain className="h-3 w-3 animate-pulse" />
                AI Agent is driving — watch only
              </div>
            </div>
          )}
        </div>

        {/* Typing + error row */}
        <div className="flex-shrink-0 space-y-1.5">
          {error && (
            <div className="text-[11px] text-rose-600 flex items-center gap-1 bg-rose-50 dark:bg-rose-950/20 px-2 py-1 rounded">
              <AlertCircle className="h-3 w-3 shrink-0" />
              <span className="truncate">{error}</span>
            </div>
          )}
          {mode === "manual" && (
            <div className="flex gap-1.5">
              <Input
                value={typingText}
                onChange={(e) => setTypingText(e.target.value)}
                placeholder="Type text here (click into a field on the page first, then type + Enter)…"
                className="h-8 text-xs"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    void handleType();
                  }
                }}
              />
              <Button size="sm" className="h-8" onClick={handleType} disabled={!typingText || isBusy}>
                Type
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2"
                onClick={() => handleKey("Enter")}
                disabled={isBusy}
                title="Press Enter"
              >
                ⏎
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2"
                onClick={() => handleKey("Backspace")}
                disabled={isBusy}
                title="Backspace"
              >
                ⌫
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2"
                onClick={() => handleAction("scroll-down")}
                disabled={isBusy}
                title="Scroll down"
              >
                ↓
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2"
                onClick={() => handleAction("scroll-up")}
                disabled={isBusy}
                title="Scroll up"
              >
                ↑
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────────────── Live Browser View (agent-run screenshots) ─────────────────── */

function LiveBrowserView({
  session,
  isRunning,
}: {
  session: SessionView;
  isRunning: boolean;
}) {
  const latestScreenshot = session.screenshots[session.screenshots.length - 1];

  return (
    <div className="space-y-3">
      {/* Browser chrome */}
      <div className="rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-950">
        {/* URL bar */}
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <div className="flex gap-1.5">
            <div className="h-2.5 w-2.5 rounded-full bg-rose-400" />
            <div className="h-2.5 w-2.5 rounded-full bg-amber-400" />
            <div className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
          </div>
          <div className="flex-1 min-w-0 flex items-center gap-1.5 bg-white dark:bg-slate-800 rounded-md px-2 py-1 text-xs text-slate-600 dark:text-slate-300 font-mono truncate">
            {isRunning ? (
              <Loader2 className="h-3 w-3 animate-spin text-emerald-500 shrink-0" />
            ) : (
              <Globe className="h-3 w-3 text-slate-400 shrink-0" />
            )}
            <span className="truncate">
              {session.currentPageUrl || "about:blank"}
            </span>
          </div>
          {isRunning && (
            <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[10px] animate-pulse">
              LIVE
            </Badge>
          )}
        </div>

        {/* Screenshot display */}
        <div className="relative bg-slate-50 dark:bg-slate-900" style={{ aspectRatio: "1366 / 850" }}>
          {latestScreenshot ? (
            <>
              <img
                src={`${latestScreenshot.path}?t=${latestScreenshot.ts}`}
                alt={latestScreenshot.caption}
                className="absolute inset-0 w-full h-full object-contain object-top"
              />
              {/* Caption overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                <div className="text-xs text-white font-medium truncate">
                  {latestScreenshot.caption}
                </div>
                <div className="text-[10px] text-white/70">
                  {timeAgo(latestScreenshot.ts)}
                  {session.currentPageTitle ? ` · ${session.currentPageTitle}` : ""}
                </div>
              </div>
            </>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
              {isRunning ? (
                <>
                  <Loader2 className="h-8 w-8 animate-spin text-emerald-500 mb-2" />
                  <p className="text-sm font-medium">Waiting for first screenshot…</p>
                  <p className="text-xs mt-1">The agent is launching its browser.</p>
                </>
              ) : (
                <>
                  <Globe className="h-8 w-8 mb-2" />
                  <p className="text-sm">No screenshot yet</p>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick info */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-md border border-slate-200 dark:border-slate-800 p-2">
          <div className="text-slate-500">Page title</div>
          <div className="font-medium truncate">
            {session.currentPageTitle || "—"}
          </div>
        </div>
        <div className="rounded-md border border-slate-200 dark:border-slate-800 p-2">
          <div className="text-slate-500">Screenshots captured</div>
          <div className="font-medium">{session.screenshots.length}</div>
        </div>
      </div>

      {session.screenshots.length > 1 && (
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {session.screenshots.slice(-8).map((sc) => (
            <img
              key={sc.id}
              src={sc.path}
              alt={sc.caption}
              className="h-12 w-16 object-cover object-top rounded border border-slate-200 dark:border-slate-800 shrink-0"
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────────────── Stats rail ─────────────────── */

function StatsRail({ session }: { session: SessionView | null }) {
  const stats = session?.stats ?? { actionsCompleted: 0, quizzesAnswered: 0, videosWatched: 0, pagesVisited: 0 };
  const items = [
    { label: "Actions done", value: stats.actionsCompleted, icon: CheckCircle2, color: "text-emerald-600" },
    { label: "Quizzes answered", value: stats.quizzesAnswered, icon: Trophy, color: "text-amber-600" },
    { label: "Videos watched", value: stats.videosWatched, icon: Video, color: "text-rose-600" },
    { label: "Pages visited", value: stats.pagesVisited, icon: Globe, color: "text-cyan-600" },
  ];
  return (
    <Card className="border-slate-200 dark:border-slate-800">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2"><Zap className="h-4 w-4" />Run stats</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-2">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <div key={it.label} className="rounded-lg border border-slate-200 dark:border-slate-800 p-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Icon className={`h-3.5 w-3.5 ${it.color}`} />
                {it.label}
              </div>
              <div className="mt-1 text-2xl font-bold tabular-nums">{it.value}</div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

/* ─────────────────── History rail ─────────────────── */

function HistoryRail({
  history,
  onLoad,
  onDelete,
  onRefresh,
  currentSessionId,
}: {
  history: HistoryItem[];
  onLoad: (id: string) => void;
  onDelete: (id: string) => void;
  onRefresh: () => void;
  currentSessionId: string | null;
}) {
  return (
    <Card className="border-slate-200 dark:border-slate-800">
      <CardHeader className="pb-2 flex-row items-center justify-between space-y-0">
        <CardTitle className="text-sm flex items-center gap-2"><History className="h-4 w-4" />Recent runs</CardTitle>
        <Button variant="ghost" size="sm" onClick={onRefresh} className="h-7 px-2">
          <RefreshCw className="h-3.5 w-3.5" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
        {history.length === 0 ? (
          <div className="text-xs text-slate-500 italic py-6 text-center">No runs yet.</div>
        ) : (
          history.map((h) => {
            const meta = STATUS_META[h.status];
            const Icon = meta.icon;
            const isCurrent = h.id === currentSessionId;
            const isRunning =
              h.status === "running" ||
              h.status === "planning" ||
              h.status === "queued";
            return (
              <div
                key={h.id}
                className={`group w-full text-left rounded-lg border p-2.5 transition-colors ${
                  isCurrent
                    ? "border-emerald-300 dark:border-emerald-700 bg-emerald-50/40 dark:bg-emerald-950/20"
                    : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                }`}
              >
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onLoad(h.id)}
                    className="flex-1 min-w-0"
                  >
                    <div className="flex items-center gap-2">
                      <Badge className={`border ${meta.color} text-[10px] rounded-full`}>
                        <Icon className="h-2.5 w-2.5 mr-1" />
                        {meta.label}
                      </Badge>
                      <span className="text-[10px] text-slate-400 ml-auto">{timeAgo(h.createdAt)}</span>
                    </div>
                    <div className="mt-1 text-xs font-medium line-clamp-2">{h.prompt}</div>
                    <div className="mt-1 text-[10px] text-slate-500 flex gap-2">
                      <span>{h.actionCount} steps</span>
                      {h.stats.quizzesAnswered ? <span>· {h.stats.quizzesAnswered} Q</span> : null}
                      {h.stats.videosWatched ? <span>· {h.stats.videosWatched} V</span> : null}
                      {h.stats.pagesVisited ? <span>· {h.stats.pagesVisited} P</span> : null}
                    </div>
                  </button>
                  {!isRunning ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(h.id);
                      }}
                      title="Delete session"
                      aria-label="Delete session"
                    >
                      <XCircle className="h-3.5 w-3.5" />
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}

/* ─────────────────── ITZA Sign-In Card ─────────────────── */

function ItzaSignInCard({
  credentials,
  onChange,
  includeCreds,
  onToggleCreds,
}: {
  credentials: { email: string; password: string };
  onChange: (v: { email: string; password: string }) => void;
  includeCreds: boolean;
  onToggleCreds: (v: boolean) => void;
}) {
  const [showPassword, setShowPassword] = useState(false);
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(credentials.email);
  const ready = includeCreds && emailValid && credentials.password.length > 0;

  return (
    <Card className="border-slate-200 dark:border-slate-800 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <div className="h-7 w-7 rounded-md bg-gradient-to-br from-violet-500/15 to-fuchsia-500/15 grid place-items-center">
                <LogIn className="h-4 w-4 text-violet-600" />
              </div>
              ITZA Account Sign-In
            </CardTitle>
            <CardDescription className="mt-1">
              Enter your ITZA credentials here. The agent will use them to sign in to <a href="https://www.itza.io" target="_blank" rel="noreferrer" className="underline">itza.io</a> before playing quizzes or watching courses. Credentials are kept in-memory only — never saved to disk.
            </CardDescription>
          </div>
          {ready && (
            <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 shrink-0">
              <ShieldCheck className="h-3 w-3 mr-1" /> Ready
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="itza-email" className="text-xs uppercase tracking-wide text-slate-500">
              ITZA Email
            </Label>
            <Input
              id="itza-email"
              type="email"
              autoComplete="email"
              value={credentials.email}
              onChange={(e) => onChange({ ...credentials, email: e.target.value })}
              placeholder="you@example.com"
              className={credentials.email && !emailValid ? "border-rose-400" : ""}
            />
            {credentials.email && !emailValid && (
              <p className="text-[11px] text-rose-500">Enter a valid email address</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="itza-password" className="text-xs uppercase tracking-wide text-slate-500">
              ITZA Password
            </Label>
            <div className="relative">
              <Input
                id="itza-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                value={credentials.password}
                onChange={(e) => onChange({ ...credentials, password: e.target.value })}
                placeholder="••••••••"
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="inline-flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 cursor-pointer">
            <input
              type="checkbox"
              checked={includeCreds}
              onChange={(e) => onToggleCreds(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300"
            />
            Use these credentials when running the agent
          </label>
          {includeCreds && !ready && (
            <span className="text-xs text-amber-600 inline-flex items-center gap-1">
              <AlertCircle className="h-3.5 w-3.5" />
              Enter email + password to enable
            </span>
          )}
        </div>
        <div className="rounded-md border border-amber-200 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20 p-2.5 text-xs text-amber-800 dark:text-amber-300 flex gap-2">
          <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
          <span>
            <strong>Why sign in?</strong> ITZA quizzes and most courses require an authenticated account. Without credentials, the agent can browse the homepage but cannot play quizzes or watch videos. Don&apos;t have an account? <a href="https://www.itza.io/sign-up" target="_blank" rel="noreferrer" className="underline">Sign up on itza.io</a> first.
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────────────── Credentials dialog ─────────────────── */

function CredentialsDialog({
  open,
  onOpenChange,
  credentials,
  onChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  credentials: { email: string; password: string };
  onChange: (v: { email: string; password: string }) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4" /> ITZA credentials
          </DialogTitle>
          <DialogDescription>
            Stored in-memory only — never written to disk. Used only when you tick <span className="font-medium">Attach ITZA credentials</span> on a task.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              value={credentials.email}
              onChange={(e) => onChange({ ...credentials, email: e.target.value })}
              placeholder="you@example.com"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={credentials.password}
              onChange={(e) => onChange({ ...credentials, password: e.target.value })}
              placeholder="••••••••"
            />
          </div>
          <div className="rounded-md border border-amber-200 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20 p-2.5 text-xs text-amber-800 dark:text-amber-300 flex gap-2">
            <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <span>The agent only uses these credentials for the ITZA sign-in step. Don&apos;t reuse your primary password — create a unique one.</span>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <DialogClose asChild>
            <Button onClick={() => onOpenChange(false)}>Save in-memory</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─────────────────── How it works ─────────────────── */

function HowItWorks() {
  const steps = [
    {
      icon: Brain,
      title: "1 · You describe the task",
      body: "Pick a template (Play a Quiz, Watch a Course, Browse Trending…) or write any instruction in plain English. The agent understands your goal and figures out the steps.",
    },
    {
      icon: Sparkles,
      title: "2 · LLM plans the steps",
      body: "An LLM call (via z-ai-web-dev-sdk) decomposes your prompt into an ordered plan: navigate → login → play_quiz / watch_video / browse → done. You see the plan live.",
    },
    {
      icon: Globe,
      title: "3 · Playwright drives itza.io",
      body: "A real headless Chromium (Playwright) opens itza.io and executes each step: typing credentials, clicking Start, reading quiz questions, playing <video> elements, advancing sections.",
    },
    {
      icon: Brain,
      title: "4 · LLM answers the quiz",
      body: "For each quiz question, the page text + options are sent to the LLM, which returns the best answer index. The agent clicks it and advances — looping through every question.",
    },
    {
      icon: Camera,
      title: "5 · Live screenshots & log",
      body: "After every meaningful action the agent captures a screenshot and writes a log line. Everything streams back to this dashboard within ~1.5 seconds.",
    },
    {
      icon: CheckCircle2,
      title: "6 · Summary & history",
      body: "When the run finishes, the LLM writes a 2–4 sentence summary. Sessions are kept in memory so you can scroll back through history, screenshots and logs.",
    },
  ];
  return (
    <section>
      <h3 className="text-xl font-semibold tracking-tight mb-4 flex items-center gap-2">
        <Info className="h-5 w-5 text-slate-400" /> How it works
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {steps.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.title} className="border-slate-200 dark:border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <div className="h-7 w-7 rounded-md bg-gradient-to-br from-emerald-500/15 to-cyan-500/15 grid place-items-center">
                    <Icon className="h-3.5 w-3.5 text-emerald-600" />
                  </div>
                  {s.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{s.body}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
