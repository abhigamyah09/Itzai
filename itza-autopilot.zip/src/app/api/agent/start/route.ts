import { NextRequest, NextResponse } from "next/server";
import { startAgent } from "@/lib/agent/orchestrator";
import { sessionStore } from "@/lib/agent/sessions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface StartBody {
  taskKind?: string;
  prompt?: string;
  credentials?: { email: string; password: string };
}

const VALID_KINDS = new Set([
  "quiz",
  "video",
  "browse",
  "custom",
  "login",
  "explore",
]);

const MAX_PROMPT_LEN = 2000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_EMAIL_LEN = 254;
const MAX_PASSWORD_LEN = 1024;

const FALLBACK_PROMPTS: Record<string, string> = {
  quiz: "Play the cricket quiz challenge on ITZA. Sign in first if needed, navigate to the quiz, answer every question, and finish it.",
  video: "Open the Ocean Odyssey course on ITZA and watch all its videos from start to finish.",
  browse: "Browse the trending stories on the ITZA homepage — visit each one and scroll through it.",
  explore: "Explore the ITZA homepage and catalogue all available quizzes, courses and videos.",
  login: "Sign in to ITZA with the provided credentials and land on the My ITZA dashboard.",
  custom: "Explore ITZA.",
};

export async function POST(req: NextRequest) {
  let body: StartBody;
  try {
    body = (await req.json()) as StartBody;
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 },
    );
  }

  const taskKind = body.taskKind && VALID_KINDS.has(body.taskKind)
    ? body.taskKind
    : "custom";

  const prompt = (body.prompt || "").trim() || FALLBACK_PROMPTS[taskKind];

  if (!prompt) {
    return NextResponse.json({ error: "prompt is required" }, { status: 400 });
  }
  if (prompt.length > MAX_PROMPT_LEN) {
    return NextResponse.json(
      { error: `Prompt too long (max ${MAX_PROMPT_LEN} chars)` },
      { status: 413 },
    );
  }

  // Validate credentials if provided
  if (body.credentials) {
    const { email, password } = body.credentials;
    if (!email || typeof email !== "string" || !EMAIL_RE.test(email) || email.length > MAX_EMAIL_LEN) {
      return NextResponse.json(
        { error: "A valid email is required when credentials are supplied" },
        { status: 400 },
      );
    }
    if (password && typeof password !== "string") {
      return NextResponse.json(
        { error: "Password must be a string" },
        { status: 400 },
      );
    }
    if (password && password.length > MAX_PASSWORD_LEN) {
      return NextResponse.json(
        { error: `Password too long (max ${MAX_PASSWORD_LEN} chars)` },
        { status: 413 },
      );
    }
  }

  // For "login" task, credentials are required
  if (taskKind === "login" && !body.credentials?.email) {
    return NextResponse.json(
      { error: "Email and password are required for the login task" },
      { status: 400 },
    );
  }

  try {
    const { sessionId } = await startAgent({
      taskKind,
      prompt,
      credentials: body.credentials,
    });
    return NextResponse.json({ sessionId, status: "queued" });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    // 409 for "already running" conflicts, 500 for other errors
    const isConflict = /already in progress|409/i.test(msg);
    return NextResponse.json(
      { error: isConflict ? msg : `Failed to start agent: ${msg}` },
      { status: isConflict ? 409 : 500 },
    );
  }
}

export async function GET() {
  // Return the most recent few sessions (light list)
  const sessions = sessionStore.list().slice(0, 10).map((s) => ({
    id: s.id,
    taskKind: s.taskKind,
    prompt: s.prompt,
    status: s.status,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
  }));
  return NextResponse.json({ sessions });
}
