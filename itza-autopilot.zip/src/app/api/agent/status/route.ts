import { NextRequest, NextResponse } from "next/server";
import {
  sessionStore,
  sanitizeSessionForClient,
} from "@/lib/agent/sessions";
import { getCurrentRunId } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json(
      { error: "sessionId query param is required" },
      { status: 400 },
    );
  }
  const session = sessionStore.get(sessionId);
  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }
  return NextResponse.json({
    session: sanitizeSessionForClient(session),
    currentRunId: getCurrentRunId(),
  });
}
