import { NextRequest, NextResponse } from "next/server";
import { sessionStore } from "@/lib/agent/sessions";
import { getCurrentRunId } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const { sessionId } = (await req.json().catch(() => ({}))) as {
    sessionId?: string;
  };
  if (!sessionId) {
    return NextResponse.json(
      { error: "sessionId is required" },
      { status: 400 },
    );
  }
  // Don't allow deleting the currently-running session
  if (getCurrentRunId() === sessionId) {
    return NextResponse.json(
      { error: "Cannot delete a session that is currently running. Stop it first." },
      { status: 409 },
    );
  }
  const ok = sessionStore.remove(sessionId);
  if (!ok) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}
