import { NextRequest, NextResponse } from "next/server";
import { stopAgent } from "@/lib/agent/orchestrator";
import { sessionStore } from "@/lib/agent/sessions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const { sessionId } = (await req.json().catch(() => ({}))) as {
    sessionId?: string;
  };
  if (!sessionId) {
    return NextResponse.json(
      { error: "sessionId is required" },
      { status: 400 },
    );
  }
  const session = sessionStore.get(sessionId);
  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }
  await stopAgent(sessionId);
  return NextResponse.json({ ok: true });
}
