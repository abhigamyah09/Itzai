import { NextResponse } from "next/server";
import { sessionStore } from "@/lib/agent/sessions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const sessions = sessionStore.list().map((s) => ({
    id: s.id,
    taskKind: s.taskKind,
    prompt: s.prompt,
    status: s.status,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
    startedAt: s.startedAt,
    finishedAt: s.finishedAt,
    stats: s.stats,
    actionCount: s.plan.length,
    logTail: s.log.slice(-3).map((l) => l.message),
  }));
  return NextResponse.json({ sessions });
}
