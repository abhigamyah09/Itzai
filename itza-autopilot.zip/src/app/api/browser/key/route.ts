import { NextRequest, NextResponse } from "next/server";
import { pressKey } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ALLOWED_KEYS = new Set([
  "Enter", "Tab", "Escape", "Backspace", "Delete",
  "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
  " ", "Space",
]);

export async function POST(req: NextRequest) {
  try {
    if (getBrowserMode() === "agent") {
      return NextResponse.json(
        { ok: false, error: "Agent is currently controlling the browser." },
        { status: 409 },
      );
    }
    const { key } = (await req.json().catch(() => ({}))) as { key?: string };
    if (typeof key !== "string" || !ALLOWED_KEYS.has(key)) {
      return NextResponse.json(
        { ok: false, error: "Unsupported key. Allowed: Enter, Tab, Escape, Backspace, Delete, ArrowUp/Down/Left/Right, Space" },
        { status: 400 },
      );
    }
    const normalizedKey = key === "Space" ? " " : key;
    const result = await pressKey(normalizedKey);
    return NextResponse.json(result, { status: result.ok ? 200 : 503 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `Browser not ready: ${(err as Error).message}` },
      { status: 503 },
    );
  }
}
