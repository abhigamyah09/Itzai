import { NextResponse } from "next/server";
import { ensurePage } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Triggers browser initialization in the background (fire-and-forget).
 * Called by the dashboard on mount so the browser starts loading itza.io
 * immediately, without blocking the page render.
 */
export async function POST() {
  // Fire-and-forget: start the browser but don't wait for it
  void ensurePage().catch(() => {
    /* ignore — will retry on next call */
  });
  return NextResponse.json({
    ok: true,
    mode: getBrowserMode(),
    message: "Browser initialization started in background.",
  });
}
