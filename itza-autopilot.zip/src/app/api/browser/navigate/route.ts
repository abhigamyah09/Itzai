import { NextRequest, NextResponse } from "next/server";
import { manualNavigate } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    if (getBrowserMode() === "agent") {
      return NextResponse.json(
        { ok: false, error: "Agent is currently controlling the browser." },
        { status: 409 },
      );
    }
    const { url } = (await req.json().catch(() => ({}))) as { url?: string };
    if (typeof url !== "string" || !url.trim()) {
      return NextResponse.json({ ok: false, error: "url is required" }, { status: 400 });
    }
    const result = await manualNavigate(url);
    return NextResponse.json(result, { status: result.ok ? 200 : 503 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `Browser not ready: ${(err as Error).message}` },
      { status: 503 },
    );
  }
}
