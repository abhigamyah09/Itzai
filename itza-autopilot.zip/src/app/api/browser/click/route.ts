import { NextRequest, NextResponse } from "next/server";
import { clickAt } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    // Reject clicks if the agent is driving (take-turns mode)
    if (getBrowserMode() === "agent") {
      return NextResponse.json(
        { ok: false, error: "Agent is currently controlling the browser. Wait for it to finish." },
        { status: 409 },
      );
    }
    const { x, y } = (await req.json().catch(() => ({}))) as { x?: number; y?: number };
    if (typeof x !== "number" || typeof y !== "number") {
      return NextResponse.json({ ok: false, error: "x and y numbers are required" }, { status: 400 });
    }
    const result = await clickAt(x, y);
    // 200 for success, 503 for "browser not ready" (client should retry),
    // never 500 for expected "not ready" states.
    return NextResponse.json(result, { status: result.ok ? 200 : 503 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `Browser not ready: ${(err as Error).message}` },
      { status: 503 },
    );
  }
}
