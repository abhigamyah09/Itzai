import { NextResponse } from "next/server";
import { captureScreenshotBuffer, currentPageInfo } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// A tiny 1x1 transparent PNG used as a placeholder when the browser is
// still loading. This way the <img> tag never breaks — it just shows
// nothing until a real screenshot is available.
const PLACEHOLDER_PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
  "base64",
);

export async function GET() {
  try {
    const buf = await captureScreenshotBuffer();
    if (!buf) {
      // Return a placeholder PNG (HTTP 200) instead of an error, so the
      // client's <img> tag doesn't break. The client will retry on the
      // next refresh cycle (every 800ms-1.2s).
      return new NextResponse(PLACEHOLDER_PNG as any, {
        status: 200,
        headers: {
          "Content-Type": "image/png",
          "Cache-Control": "no-store, no-cache, must-revalidate",
          "X-Browser-Mode": getBrowserMode(),
          "X-Browser-Loading": "1",
        },
      });
    }
    const info = await currentPageInfo();
    // Screenshots are JPEG (quality 70) for smaller files (~150KB vs 1.4MB PNG).
    // This is critical for mobile networks.
    return new NextResponse(buf as any, {
      status: 200,
      headers: {
        "Content-Type": "image/jpeg",
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "X-Page-Url": encodeURIComponent(info.url || ""),
        "X-Page-Title": encodeURIComponent(info.title || ""),
        "X-Browser-Mode": getBrowserMode(),
      },
    });
  } catch (err) {
    // Even on error, return the placeholder so the <img> doesn't break
    return new NextResponse(PLACEHOLDER_PNG as any, {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "X-Browser-Mode": getBrowserMode(),
        "X-Browser-Error": (err as Error).message.slice(0, 100),
      },
    });
  }
}
