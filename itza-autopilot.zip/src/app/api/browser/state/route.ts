import { NextResponse } from "next/server";
import { getBrowserMode, getCurrentRunId } from "@/lib/agent/orchestrator";
import { currentPageInfo } from "@/lib/agent/itza-engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // Don't call ensurePage() here — it blocks while the browser launches.
    // Just return the current state. The screenshot endpoint handles
    // triggering browser initialization via getActivePageQuickly().
    const info = await currentPageInfo();
    return NextResponse.json({
      mode: getBrowserMode(),
      currentRunId: getCurrentRunId(),
      pageUrl: info.url,
      pageTitle: info.title,
    });
  } catch (err) {
    return NextResponse.json(
      {
        mode: getBrowserMode(),
        currentRunId: getCurrentRunId(),
        pageUrl: "",
        pageTitle: "",
        error: `Browser not ready: ${(err as Error).message}`,
      },
      { status: 200 },
    );
  }
}
