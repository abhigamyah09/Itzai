import { NextResponse } from "next/server";
import { scrollPage } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    if (getBrowserMode() === "agent") {
      return NextResponse.json(
        { ok: false, error: "Agent is currently controlling the browser." },
        { status: 409 },
      );
    }
    const { direction } = (await req.json().catch(() => ({}))) as { direction?: string };
    if (direction !== "up" && direction !== "down") {
      return NextResponse.json({ ok: false, error: "direction must be 'up' or 'down'" }, { status: 400 });
    }
    const result = await scrollPage(direction);
    return NextResponse.json(result, { status: result.ok ? 200 : 503 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `Browser not ready: ${(err as Error).message}` },
      { status: 503 },
    );
  }
}
