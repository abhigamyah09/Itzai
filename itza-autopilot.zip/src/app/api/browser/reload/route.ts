import { NextResponse } from "next/server";
import { reload } from "@/lib/agent/itza-engine";
import { getBrowserMode } from "@/lib/agent/orchestrator";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  try {
    if (getBrowserMode() === "agent") {
      return NextResponse.json({ ok: false, error: "Agent is controlling the browser." }, { status: 409 });
    }
    const result = await reload();
    return NextResponse.json(result, { status: result.ok ? 200 : 503 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `Browser not ready: ${(err as Error).message}` },
      { status: 503 },
    );
  }
}
