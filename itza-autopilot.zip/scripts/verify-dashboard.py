"""Self-verification: visit the running dashboard and capture screenshots."""
import asyncio
from playwright.async_api import async_playwright
from pathlib import Path

URL = "http://localhost:3000/"
OUT = Path("/home/z/my-project/download/dashboard-verify")
OUT.mkdir(parents=True, exist_ok=True)


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        ctx = await browser.new_context(viewport={"width": 1440, "height": 900})
        page = await ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(f"console.{m.type}: {m.text}") if m.type == "error" else None)

        print("→ Loading", URL)
        await page.goto(URL, wait_until="networkidle", timeout=30000)
        await page.wait_for_timeout(2000)

        # Verify hero heading exists
        h2 = await page.text_content("h2")
        print("Hero h2:", repr(h2))
        assert h2 and "agent" in h2.lower(), "Hero heading should mention 'agent'"

        # Verify 6 task templates rendered.
        # The template grid is the first <section> with a grid of buttons;
        # each template button starts with one of these exact titles.
        template_titles = [
            "Play a Quiz",
            "Watch a Course",
            "Browse Trending",
            "Explore Everything",
            "Sign In Only",
            "Custom Task",
        ]
        templates = 0
        for title in template_titles:
            # Match a button whose text starts with the exact title
            count = await page.locator(
                "button", has_text=title
            ).count()
            # Be lenient: at least one button per template
            if count >= 1:
                templates += 1
        print("Templates found:", templates)
        assert templates == 6, f"Expected 6 templates, got {templates}"

        # Verify Run agent button exists
        run_btn = page.locator("button:has-text('Run agent')")
        assert await run_btn.count() >= 1
        print("Run agent button: OK")

        # Click 'Custom Task' template to test interactivity
        await page.locator("button:has-text('Custom Task')").click()
        await page.wait_for_timeout(300)
        prompt_value = await page.locator("textarea#prompt").input_value()
        print("Prompt after clicking Custom Task:", prompt_value[:80])
        assert "Egypt" in prompt_value, "Custom Task template should populate prompt"

        # Take desktop screenshot
        await page.screenshot(path=str(OUT / "dashboard-desktop.png"), full_page=False)
        print("✓ Desktop screenshot saved")

        # Test mobile responsive
        await page.set_viewport_size({"width": 375, "height": 812})
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(OUT / "dashboard-mobile.png"), full_page=False)
        print("✓ Mobile screenshot saved")

        # Scroll to bottom and capture footer
        await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await page.wait_for_timeout(300)
        await page.screenshot(path=str(OUT / "dashboard-footer.png"), full_page=False)
        print("✓ Footer screenshot saved")

        # Open credentials dialog
        await page.evaluate("window.scrollTo(0, 0)")
        await page.wait_for_timeout(300)
        await page.set_viewport_size({"width": 1440, "height": 900})
        await page.wait_for_timeout(300)
        await page.locator("button:has-text('Credentials')").first.click()
        await page.wait_for_timeout(500)
        dialog_visible = await page.locator("text=ITZA credentials").first.is_visible()
        print("Credentials dialog visible:", dialog_visible)
        assert dialog_visible, "Credentials dialog should open"
        await page.screenshot(path=str(OUT / "dashboard-creds-dialog.png"), full_page=False)
        print("✓ Credentials dialog screenshot saved")

        # Verify no JS errors
        if errors:
            print("⚠ JS errors detected:")
            for e in errors:
                print("  ", e)
        else:
            print("✓ No JS errors detected")

        await browser.close()
        print("\nAll verifications passed.")


asyncio.run(main())
