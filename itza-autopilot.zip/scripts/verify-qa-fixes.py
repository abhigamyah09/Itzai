"""Verify the QA fixes via the API."""
import json
import urllib.request

BASE = "http://localhost:3000"

def post(path, body):
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def get(path):
    try:
        with urllib.request.urlopen(BASE + path, timeout=10) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


print("=== Fix 7: Prompt length limit ===")
huge = "x" * 3000
status, j = post("/api/agent/start", {"taskKind": "custom", "prompt": huge})
assert status == 413, f"Expected 413, got {status}: {j}"
print(f"✓ {status}: {j.get('error')}")

print("\n=== Fix 8: Email validation ===")
status, j = post("/api/agent/start", {
    "taskKind": "custom",
    "prompt": "Explore",
    "credentials": {"email": "not-an-email", "password": "x"},
})
assert status == 400, f"Expected 400, got {status}: {j}"
print(f"✓ {status}: {j.get('error')}")

# Valid email should pass validation
status, j = post("/api/agent/start", {
    "taskKind": "custom",
    "prompt": "Explore the ITZA homepage only.",
    "credentials": {"email": "test@example.com", "password": "secret123"},
})
assert status == 200, f"Expected 200, got {status}: {j}"
print(f"✓ Valid email accepted: session {j.get('sessionId')}")
test_session = j.get("sessionId")

print("\n=== Wait for session to finish (max 30s) ===")
import time
for i in range(15):
    time.sleep(2)
    status, j = get(f"/api/agent/status?sessionId={test_session}")
    s = j.get("session", {}).get("status")
    print(f"  [{i*2}s] status={s}")
    if s in ("completed", "failed", "stopped"):
        break

print("\n=== Inspect final session state ===")
status, j = get(f"/api/agent/status?sessionId={test_session}")
sess = j.get("session", {})
print(f"Final status: {sess.get('status')}")
print(f"Plan: {len(sess.get('plan', []))} action(s)")
for a in sess.get("plan", []):
    print(f"  #{a['index']+1} [{a['status']}] {a['type']}: {a['description'][:60]}")
print(f"Stats: {sess.get('stats')}")
print(f"Screenshots: {len(sess.get('screenshots', []))}")

# Verify the security gate (custom loop) didn't go to evil.com
for log in sess.get("log", []):
    msg = log.get("message", "")
    if "evil" in msg.lower() or "blocked" in msg.lower() or "non-itza" in msg.lower():
        print(f"✓ Security log: {msg}")

print("\n=== Fix 16: Delete session ===")
# Should be deletable now that it's completed
status, j = post("/api/agent/delete", {"sessionId": test_session})
print(f"Delete status: {status}, body: {j}")
assert status == 200, f"Expected 200, got {status}: {j}"
# Verify it's gone
status, j = get(f"/api/agent/status?sessionId={test_session}")
assert status == 404, f"Expected 404 after delete, got {status}: {j}"
print("✓ Session deleted and is now 404")

print("\n=== Fix 16b: Can't delete a running session ===")
# Start a fresh session
status, j = post("/api/agent/start", {"taskKind": "explore", "prompt": "Explore ITZA"})
assert status == 200
running_session = j["sessionId"]
# Immediately try to delete it — should be 409
status, j = post("/api/agent/delete", {"sessionId": running_session})
print(f"Delete running session: status={status}, body={j}")
assert status == 409, f"Expected 409, got {status}: {j}"
print("✓ Cannot delete running session")
# Stop it
post("/api/agent/stop", {"sessionId": running_session})
import time as t
t.sleep(8)

print("\n=== All QA fixes verified ===")
