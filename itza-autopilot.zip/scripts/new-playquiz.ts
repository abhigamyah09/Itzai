// Navigation/button texts that are NEVER quiz answers.
const NAV_BUTTON_PATTERNS =
  /^(start(\s+quiz)?!?|begin|continue|next(\s+question)?|submit|finish|skip|back|cancel|sign\s*in|sign\s*up|log\s*in|log\s*out|home|menu|close|got\s*it|ok|okay|play|watch|learn\s*more|explore|get\s*started|enter|see\s*all|check\s*out|feedback|help|privacy|cookies|terms)$/i;

export async function playQuiz(
  sessionId: string,
  actionIndex: number,
  target?: string,
): Promise<{ questionsAnswered: number }> {
  const desc = `Play quiz${target ? `: ${target}` : ""}`;
  let answered = 0;
  await withAction(sessionId, actionIndex, desc, async () => {
    const page = await ensurePage();
    const url = await resolveCourseUrl(page, target, DEFAULT_QUIZ_URLS);
    sessionStore.log(sessionId, "info", `Resolved quiz URL: ${url}`);
    await page.goto(url, { waitUntil: "domcontentloaded" });
    await sleep(2000);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "Quiz landing page", actionIndex);

    // STEP 1: Click "Start Quiz" / "Start" / "Begin" to ENTER the quiz.
    sessionStore.log(sessionId, "info", "Looking for Start button to begin quiz…");
    const startClicked =
      (await safeClickByText(page, "Start Quiz!")) ||
      (await safeClickByText(page, "Start Quiz")) ||
      (await safeClickByText(page, "Start")) ||
      (await safeClickByText(page, "Begin")) ||
      (await safeClickByText(page, "Get Started")) ||
      (await safeClickByText(page, "Get started"));
    if (startClicked) {
      sessionStore.log(sessionId, "success", "Clicked Start to enter the quiz.");
    } else {
      sessionStore.log(sessionId, "warn", "No Start button found — may already be inside the quiz.");
    }
    await sleep(2500);
    await recordCurrentPage(sessionId);
    await snapshot(sessionId, "After clicking Start", actionIndex);

    // STEP 2: Check for login wall. ITZA gates quizzes behind auth.
    const pageText = await page
      .evaluate(() => document.body.innerText || "")
      .catch(() => "");
    const needsLogin =
      /log\s*in\s*to\s*(take|play|see)/i.test(pageText) ||
      /please\s*log\s*in/i.test(pageText) ||
      /sign\s*in\s*to\s*(take|play|see)/i.test(pageText);
    if (needsLogin) {
      sessionStore.log(
        sessionId,
        "error",
        "LOGIN REQUIRED: This quiz needs you to be signed in. Provide ITZA credentials (tick 'Attach ITZA credentials') and use a 'login' step BEFORE the quiz step. The agent cannot answer quiz questions without authentication.",
      );
      await snapshot(sessionId, "Login wall detected", actionIndex);
      return;
    }

    // STEP 3: Answer up to 30 questions in a loop.
    for (let q = 0; q < 30; q++) {
      if (sessionStore.get(sessionId)?.stopRequested) {
        sessionStore.log(sessionId, "warn", "Stop requested — exiting quiz loop.");
        break;
      }

      const currentText = await page
        .evaluate(() => document.body.innerText || "")
        .catch(() => "");

      // Check for definitive end-of-quiz markers FIRST. Require an actual
      // score number, not just the word "results".
      const scoreMatch = currentText.match(/\d+\s*\/\s*\d+|score\s*[:=]?\s*\d+|you\s+scored/i);
      const hasResults =
        (scoreMatch && /score|result|congratulations|well\s*done/i.test(currentText)) ||
        /quiz\s+complete|you\s+have\s+finished/i.test(currentText);
      if (hasResults && q > 0) {
        sessionStore.log(sessionId, "success", `Quiz results screen reached after ${answered} question(s).`);
        await snapshot(sessionId, "Quiz results", actionIndex);
        break;
      }

      // Detect clickable options on the current screen.
      const qData = await page
        .evaluate(() => {
          const optionEls = Array.from(
            document.querySelectorAll(
              'button, [role="button"], label, li, a, [role="option"], [role="radio"]',
            ),
          );
          const options: { text: string; tag: string }[] = [];
          for (const el of optionEls) {
            const t = (el.textContent || "").trim();
            if (t.length < 1 || t.length > 200) continue;
            const r = (el as HTMLElement).getBoundingClientRect();
            if (r.width < 60 || r.height < 20) continue;
            const parent = (el as HTMLElement).closest("nav, header, footer");
            if (parent) continue;
            options.push({ text: t.slice(0, 200), tag: el.tagName });
            if (options.length >= 12) break;
          }
          return { options };
        })
        .catch(() => ({ options: [] as { text: string; tag: string }[] }));

      let realOptions = (qData.options || []).filter(
        (o) => !NAV_BUTTON_PATTERNS.test(o.text),
      );
      realOptions = realOptions.filter((o) => o.text.length <= 100);

      if (realOptions.length < 2) {
        const advanced =
          (await safeClickByText(page, "Next")) ||
          (await safeClickByText(page, "Next question")) ||
          (await safeClickByText(page, "Continue")) ||
          (await safeClickByText(page, "Submit")) ||
          (await safeClickByText(page, "Finish"));
        if (advanced) {
          sessionStore.log(
            sessionId,
            "info",
            "No question on this screen — clicked Next/Continue to advance.",
          );
          await sleep(1500);
          continue;
        }
        if (q === 0) {
          sessionStore.log(
            sessionId,
            "warn",
            "No quiz questions detected on this page. The quiz may require login, may have changed layout, or may not have started. Check the screenshot.",
          );
        } else {
          sessionStore.log(
            sessionId,
            "info",
            `Finished after ${answered} question(s) — no more questions detected.`,
          );
        }
        await snapshot(sessionId, `Quiz state (Q${q + 1})`, actionIndex);
        break;
      }

      const questionText = await page
        .evaluate(() => {
          const candidates = Array.from(
            document.querySelectorAll("h1,h2,h3,h4,h5,p,div,span"),
          );
          let best = "";
          for (const el of candidates) {
            const t = (el.textContent || "").trim();
            if (t.length < 10 || t.length > 400) continue;
            const r = (el as HTMLElement).getBoundingClientRect();
            if (r.width < 200 || r.top > 500) continue;
            if (t.includes("?") && t.length > best.length) {
              best = t;
            }
          }
          if (!best) {
            for (const el of candidates) {
              const t = (el.textContent || "").trim();
              if (t.length < 15 || t.length > 300) continue;
              const r = (el as HTMLElement).getBoundingClientRect();
              if (r.width < 200 || r.top > 400) continue;
              if (/sign|cookie|start\s*quiz|terms|privacy/i.test(t)) continue;
              if (t.length > best.length) best = t;
            }
          }
          return best.slice(0, 400);
        })
        .catch(() => "");

      const opts = realOptions.map((o) => o.text);
      sessionStore.log(
        sessionId,
        "info",
        `Q${q + 1}: ${questionText.slice(0, 100) || "(question text not isolated)"} → ${opts.length} options: ${opts.map((o) => o.slice(0, 30)).join(" | ")}`,
      );

      const decision = await answerQuizQuestion(
        questionText || currentText.slice(0, 600),
        opts,
      );
      const chosenText = opts[decision.answerIndex] || "";
      sessionStore.log(
        sessionId,
        "info",
        `→ Answering Q${q + 1}: "${chosenText.slice(0, 50)}" (${decision.reasoning})`,
      );

      const clicked = await page
        .evaluate((txt: string) => {
          const els = Array.from(
            document.querySelectorAll(
              'button, [role="button"], label, li, a, [role="option"], [role="radio"]',
            ),
          ).filter((el) => {
            const t = (el.textContent || "").trim();
            const r = el.getBoundingClientRect();
            return (
              t.length > 0 &&
              t.length <= 200 &&
              r.width > 60 &&
              r.height > 20 &&
              !el.closest("nav, header, footer")
            );
          });
          const target = els.find((el) => (el.textContent || "").trim() === txt);
          if (!target) return false;
          (target as HTMLElement).click();
          return true;
        }, chosenText)
        .catch(() => false);

      if (!clicked) {
        sessionStore.log(
          sessionId,
          "warn",
          `Could not click option "${chosenText.slice(0, 40)}" — trying Next to advance.`,
        );
      } else {
        answered += 1;
        const s = sessionStore.get(sessionId);
        if (s) s.stats.quizzesAnswered += 1;
      }

      await sleep(1000);
      await snapshot(sessionId, `Q${q + 1} answered`, actionIndex);

      const advanced =
        (await safeClickByText(page, "Next")) ||
        (await safeClickByText(page, "Next question")) ||
        (await safeClickByText(page, "Submit")) ||
        (await safeClickByText(page, "Continue")) ||
        (await safeClickByText(page, "Finish"));
      await sleep(1500);
      if (advanced) continue;

      const endText = await page
        .evaluate(() => document.body.innerText || "")
        .catch(() => "");
      if (
        /\d+\s*\/\s*\d+|score\s*[:=]?\s*\d+|you\s+scored|quiz\s+complete/i.test(endText)
      ) {
        sessionStore.log(sessionId, "success", `Quiz results screen reached after ${answered} question(s).`);
        await snapshot(sessionId, "Quiz results", actionIndex);
        break;
      }
    }
  });
  return { questionsAnswered: answered };
}
